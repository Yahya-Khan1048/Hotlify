import express from "express";

import morgan from "morgan"; // this package tell us which request has been hit
import connectDB from "./config/db.js";
import dotenv from "dotenv";
import roomRoute from "./routes/roomRoute.js";
import userRoute from "./routes/userRoute.js";
import jobRoute from "./routes/jobRoute.js";
import applyRoute from "./routes/applyRoute.js";
import hotelRoute from "./routes/hotelRoute.js";
import bookingRoute from "./routes/bookingRoute.js";
import colors from "colors";
import cors from "cors";

// Configure env

dotenv.config();

// rest object
const app = express();
// Connect databae

connectDB();
// middleware
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));
// routes

app.use("/api/v1/rooms", roomRoute);
app.use("/api/v1/hotel", hotelRoute);
app.use("/api/v1/booking", bookingRoute);
app.use("/api/v1/user", userRoute);
app.use("/api/v1/job", jobRoute);
app.use("/api/v1/apply", applyRoute);

app.get("/", (req, res) => {
  res.send("<h1>Welcome Hotel Management system</h1>");
});

// server listening port

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(
    `Server is running on ${process.env.DEV_MODE} on port ${PORT}`.bgGreen.white
      .bold
  );
});
