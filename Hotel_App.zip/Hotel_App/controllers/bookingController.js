import bookingModel from "../Models/bookingModel.js";
//=================  end ===============//

export const createBookingController = async (req, res) => {
  try {
    const {
      name,
      email,
      phoneNumber,
      checkInDate,
      checkOutDate,
      numberOfGuests,
      address,
      userId,
      roomId,
    } = req.body;
    const booking = new bookingModel({
      name,
      email,
      phoneNumber,
      checkInDate,
      checkOutDate,
      numberOfGuests,
      address,
      user: userId,
      room: roomId, // changed from bookingId to roomId
    });
    await booking.save();
    res
      .status(200)
      .send({ success: true, message: "Room booked successfully", booking });
  } catch (error) {
    console.log(error);
    res
      .status(400)
      .send({ success: false, message: "Error in booking a room", error });
  }
};

//======== Fetch booking at user side ==========
export const getAllBookingController = async (req, res) => {
  try {
    const AllBooking = await bookingModel.find();
    res.status(200).send({
      success: true,
      message: "All Booking Fetch successfully",
      count: AllBooking.length,
      data: AllBooking,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while getting all the booking",
      error,
    });
  }
};
export const getAllUserBookingController = async (req, res) => {
  try {
    const AllBooking = await bookingModel.find();
    res.status(200).send({
      success: true,
      message: "All Booking Fetch successfully",
      count: AllBooking.length,
      data: AllBooking,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while getting all the booking",
      error,
    });
  }
};

//===================== Accept booking ====================
export const acceptBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedBooking = await bookingModel.findByIdAndUpdate(
      id,
      {
        status: "Accepted",
      },
      { new: true }
    );
    res.status(200).send({
      success: true,
      message: "Booking accepted successfully",
      data: updatedBooking,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while accepting booking",
    });
  }
};

//================= Reject Booking =======================
export const rejectBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedBooking = await bookingModel.findByIdAndUpdate(
      id,
      {
        status: "Rejected",
      },
      { new: true }
    );
    res.status(200).send({
      success: true,
      message: "Booking rejected successfully",
      data: updatedBooking,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while rejecting booking",
    });
  }
};

//============== Delete Booking at user side===============
export const deleteBookingController = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedBooking = await bookingModel.findByIdAndDelete(id);
    if (!deletedBooking) {
      return res.status(404).send({
        success: false,
        message: "Booking not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Booking deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while deleting booking",
    });
  }
};

// ====== Payment gateway api

//for token
export const braintreeTokenController = async (req, res) => {
  try {
    gateway.clientToken.generate({}, function (err, response) {
      if (err) {
        res.status(500).send(err);
      } else {
        res.send(response);
      }
    });
  } catch (error) {
    console.log(error);
  }
};
// for payment
export const brainTreePaymentController = async (req, res) => {
  try {
    const { nonce, cart } = req.body;
    let total = 0;
    cart.map((i) => {
      total += i.price;
    });
    let newTransaction = gateway.transaction.sale(
      {
        amount: total,
        paymentMethodNonce: nonce,
        options: {
          submitForSettlement: true,
        },
      },
      function (error, result) {
        if (result) {
          const order = new orderModel({
            products: cart,
            payment: result,
            buyer: req.user._id,
          }).save();
          res.json({ ok: true });
        } else {
          res.status(500).send(error);
        }
      }
    );
  } catch (error) {
    console.log(error);
  }
};
