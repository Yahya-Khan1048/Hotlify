import hotelModel from "../Models/Hotel.js";
export const createController = async (req, res) => {
  try {
    const {
      name,
      address,
      phone,
      email,
      stars,
      checkinTime,
      checkoutTime,
      description,
      status,
    } = req.body;
    const images = req.files.map((file) => file.filename);
    const hotel = new hotelModel({
      name,
      address,
      phone,
      email,
      stars,
      checkinTime,
      checkoutTime,
      description,
      status,
      images: images,
      user: req.body.userId,
    });
    await hotel.save();
    res.status(200).send({
      success: true,
      message: "Hotel is created successfully",
      hotel,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while creating Hotel",
      error,
    });
  }
};

export const getAllHotelController = async (req, res) => {
  try {
    const allHotel = await hotelModel.find();
    res.status(200).send({
      success: true,
      message: "Total avaliable Hotels",
      count: allHotel.length,
      data: allHotel,
    });
  } catch (error) {
    console.log(error);
    res.status(404).send({
      success: false,
      message: "Error while getting Hotels",
      error,
    });
  }
};
