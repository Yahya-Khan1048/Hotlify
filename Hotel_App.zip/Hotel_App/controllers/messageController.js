import chatModel from "../Models/chatModel.js"; // conversation model
import Message from "../Models/messageModel.js";
import Users from "../Models/userModel.js";

//============ Store a Messages ===========
export const sendingMessageController = async (req, res) => {
  try {
    const { userId, message } = req.body;
    const { id: reciverId } = req.params;

    const senderId = userId;
    //======== Validation ==========
    // if (!userId || !message || !id) {
    //   return res.send({ message: "Required all field" });
    // }
    // ---- checking if chat is already available if not then create it
    let chats = await chatModel.findOne({
      participants: { $all: [userId, reciverId] },
    });

    if (!chats) {
      chats = await chatModel.create({
        participants: [senderId, reciverId],
      });
    }
    const newMessages = new Message({
      senderId,
      reciverId,
      message,
      conversationId: chats._id,
    });

    if (newMessages) {
      chats.message.push(newMessages._id);
    }
    // socket Io function
    await Promise.all([chats.save(), newMessages.save()]);
    res.status(201).send({
      success: true,
      message: "Message send Successully",
      newMessages,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while sending messages",
      error,
    });
  }
};

//=============== Getting all Messages =============
export const getMessageController = async (req, res) => {
  try {
    const messages = await Message.find({ chat: req.params.chatId })
      .populate("sender", "name email")
      .populate("chat");
    res.status(201).send({
      success: true,
      message: "send messages Successully",
      messages,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in sending messages",
      error,
    });
  }
};
