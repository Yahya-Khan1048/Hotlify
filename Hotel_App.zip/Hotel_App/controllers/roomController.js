import roomModel from "../Models/roomModel.js";
// import fs from "fs";
// import path from "path";
// import { fileURLToPath } from "url";

//================ Creating a room ==================
export const createRoomController = async (req, res) => {
  try {
    const {
      name,
      pricePerNight,
      description,
      address,
      guestCapacity,
      numOfBeds,
      internet,
      breakfast,
      ac,
      petAllowed,
      roomCleaning,
      category,
      hotelId, // Get the hotelId from the request body
    } = req.body;
    const images = req.files.map((file) => file.filename);
    const room = new roomModel({
      name,
      pricePerNight,
      description,
      address,
      guestCapacity,
      numOfBeds,
      internet,
      breakfast,
      ac,
      petAllowed,
      roomCleaning,
      category,
      images: images,
      user: req.body.userId,
      hotel: hotelId, // Add the hotelId to the room model
    });
    await room.save();
    res.status(200).send({
      success: true,
      message: "Room is created successfully",
      room,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while creating room",
      error,
    });
  }
};

// ============================ Getting all Room from Database ===========================

export const allRoomController = async (req, res) => {
  try {
    const rooms = await roomModel.find(); // Find all rooms where isAvailable is true
    res.status(200).send({
      success: true,
      message: "All available rooms fetched successfully",
      rooms,
    });
  } catch (error) {
    console.log(error);
    res.status(404).send({
      success: false,
      message: "Error while fetching all available rooms",
      error,
    });
  }
};

//======= Getting all room associated hotels ==============

export const getAllRoomController = async (req, res) => {
  try {
    const { id } = req.params; // Use req.params instead of req.body
    const rooms = await roomModel.find({ hotel: id }); // Find all rooms with the given hotel id
    if (rooms) {
      res.status(200).send({
        success: true,
        message: "Rooms found",
        data: rooms,
      });
    } else {
      res.status(404).send({
        success: false,
        message: "No rooms found",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(404).send({
      success: false,
      message: "Error while getting rooms",
      error,
    });
  }
};

//================ Getting Single room ==============

export const getSingleRoom = async (req, res) => {
  try {
    const { id } = req.params; // Get the room ID from URL parameter

    // Check if room ID is provided
    if (!id) {
      return res.status(400).send({
        success: false,
        message: "Room ID is required",
      });
    }

    // Find the room by ID with authorization (optional)
    const room = await roomModel.findById(id);

    // Check if room  does not exists
    if (!room) {
      return res.status(404).send({
        success: false,
        message: "Room not found",
      });
    }

    // Return the room details
    return res.status(200).send({
      success: true,
      message: "Fetch single room details successfully",
      data: room,
    });
  } catch (error) {
    console.log(error);
    res.status(404).send({
      success: false,
      message: "Error while getting single rooms",
      error,
    });
  }
};

//================== Getting single room at User side ================
export const getUserRoomController = async (req, res) => {
  try {
    const { id } = req.params; // Get the room ID from URL parameter

    // Check if room ID is provided
    if (!id) {
      return res.status(400).send({
        success: false,
        message: "Room ID is required",
      });
    }

    // Find the room by ID with authorization (optional)
    const room = await roomModel.findById(id);

    // Check if room does not exist
    if (!room) {
      return res.status(404).send({
        success: false,
        message: "Room not found",
      });
    }

    // Return the room details
    return res.status(200).send({
      success: true,
      message: "Fetch single room details successfully",
      data: room,
    });
  } catch (error) {
    console.log(error); // Log the error for debugging
    res.status(404).send({
      success: false,
      message: "Error while getting single rooms",
      error,
    });
  }
};
//============= Update room Details ===========
export const updateRoomController = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedRoomDetails = req.body;
    const room = await roomModel.findByIdAndUpdate(id, updatedRoomDetails, {
      new: true,
    });
    if (!room) {
      return res
        .status(404)
        .send({ success: false, message: "Room not found" });
    }
    res.send({ success: true, message: "Room updated successfully", room });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      success: false,
      message: "Error in updating room details",
    });
  }
};

//================ change room booking status to booking =============

export const bookRoomController = async (req, res) => {
  try {
    const { id } = req.params;
    const room = await roomModel.findByIdAndUpdate(
      id,
      { status: "Booked" },
      { new: true }
    );
    if (!room) {
      return res
        .status(404)
        .send({ success: false, message: "Room not found" });
    }
    res
      .status(200)
      .send({ success: true, message: "Room booked successfully" });
  } catch (error) {
    res.status(500).send({ success: false, message: "Something went wrong" });
  }
};
//================ change room booking status to booking =============
export const releaseRoomController = async (req, res) => {
  try {
    const { id } = req.params;
    const room = await roomModel.findByIdAndUpdate(
      id,
      { status: "released" },
      { new: true }
    );
    if (!room) {
      return res
        .status(404)
        .send({ success: false, message: "Room not found" });
    }
    res
      .status(200)
      .send({ success: true, message: "Room released successfully" });
  } catch (error) {
    res.status(500).send({ success: false, message: "Something went wrong" });
  }
};

//=========== Searching room ===========

export const searchRoomController = async (req, res) => {
  try {
    const { keyword } = req.params; // extract keyword
    const resutls = await roomModel.find({
      // Exracting product through keyword that may be match with name or description
      $or: [
        { category: { $regex: keyword, $options: "i" } }, // i mean remove the case sensitive
        { address: { $regex: keyword, $options: "i" } },
      ],
    });
    res.status(200).send({
      success: true,
      count: resutls.length,
      resutls,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error in Searching room",
      error,
    });
  }
};

// const __dirname = path.dirname(fileURLToPath(import.meta.url));

//=============== Delete room =============
export const deleteRoomController = async (req, res) => {
  try {
    const { id } = req.params;
    const room = await roomModel.findById(id);
    if (!room) {
      res.status(404).send({ success: false, message: "Room not found" });
    } else {
      // Delete images from directory
      // const imagesDir = path.join(__dirname, "../client/src/images/");
      // room.images.forEach((image) => {
      //   const imagePath = path.join(imagesDir, image);
      //   try {
      //     fs.unlinkSync(imagePath);
      //   } catch (err) {
      //     console.error(err);
      //   }
      // });
      await roomModel.findByIdAndDelete(id);
      res
        .status(200)
        .send({ success: true, message: "Room Deleted Successfully" });
    }
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send({ success: false, message: "Error while deleting Room", error });
  }
};
