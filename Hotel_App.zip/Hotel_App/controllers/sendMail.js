import nodemailer from "nodemailer";
export const sendMail = async (req, res) => {
  try {
    // Create a test account or use your own SMTP credentials
    let testAccount = await nodemailer.createTestAccount();

    // Connect to the SMTP server
    let transporter = await nodemailer.createTransport({
      host: "smtp.ethereal.email",
      port: 587,
      secure: false, // or 'STARTTLS'
      auth: {
        user: "madge44@ethereal.email",
        pass: "41WXqkWyJVm5WZYFN6",
      },
      connectionTimeout: 30000, // 30 seconds
    });

    // Send the email
    let info = await transporter.sendMail({
      from: '"Yahya Khan 👻" <jobs28000@gmail.com>',
      to: "madge44@ethereal.email",
      subject: "Hello Thapa",
      text: "Hello YT Thapa",
      html: "<b>Hello YT Thapa</b>",
    });

    console.log("Message sent: %s", info.messageId);
    res.send(info);
  } catch (error) {
    console.error(error);
    res.status(500).send("Error sending email");
  }
};
