import chatModel from "../Models/chatModel.js";
import userModel from "../Models/userModel.js";

export const createChatController = async (req, res) => {
  try {
    const { users } = req.body;
    const [userId, currentUserId] = users;
    if (!userId || !currentUserId) {
      return res.status(200).send({
        success: false,
        message: "User id not found",
      });
    }
    var isChat = await chatModel
      .find({
        isGroupChat: false,
        $and: [
          { users: { $elemMatch: { $eq: currentUserId } } },
          { users: { $elemMatch: { $eq: userId } } },
        ],
      })
      .populate("users", "-password")
      .populate("latestMessage");
    isChat = await chatModel.populate(isChat, {
      path: "latestMessage.sender",
      model: "Users",
      select: "name language email",
    });
    if (isChat.length > 0) {
      return res.send({ success: true, data: isChat[0] });
    } else {
      var chatData = {
        chatName: "sender",
        isGroupChat: false,
        users: [currentUserId, userId],
      };
      const createdChat = await chatModel.create(chatData);
      const FullChat = await chatModel
        .findOne({ _id: createdChat._id })
        .populate("users", "-password");
      return res.status(200).send({
        success: true,
        message: "Single chat is created",
        data: FullChat,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while getting search result",
      error,
    });
  }
};

//============== Functio to fetch chat for a user ===========
export const getSingleChatController = async (req, res) => {
  try {
    // Find chats where the user is a participant
    const userId = req.query.userId; // Get user ID from query parameter
    // Find chats where the user is a participant
    const chats = await chatModel
      .find({
        users: { $elemMatch: { $eq: userId } },
      })
      // Populate user data without passwords
      .populate("users", "-password")
      // Populate group admin data without password
      .populate("groupAdmin", "-password")
      // Populate latest message data
      .populate("latestMessage")
      // Sort chats by new to old
      .sort({ updatedAt: -1 });
    // Populate sender data for latest messages
    const populatedChats = await userModel.populate(chats, {
      path: "latestMessage.sender",
      select: "name language email",
    });
    // Send response with chat data
    res.status(200).send({
      success: true,
      message: "Fetch chat successfully",
      data: populatedChats,
    });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send({ message: "Error fetching chats", success: false, error });
  }
};

//======================  Create group chat ==========

export const createGroupChatController = async (req, res) => {
  try {
    // Check if required fields are present
    if (!req.body.users || !req.body.name || !req.body.currentUserId) {
      return res
        .status(400)
        .send({ message: "Please fill all the fields", success: false });
    }

    // Parse users from request body
    const users = JSON.parse(req.body.users);

    // Check if minimum 2 users are present
    if (users.length < 2) {
      return res.status(400).send({
        message: "More than 2 users are required to form a group chat",
        success: false,
      });
    }

    // Add current user to the group
    users.push(req.body.currentUserId); // Use the passed current user's ID

    // Create group chat
    const groupChat = await chatModel.create({
      chatName: req.body.name,
      users: users,
      isGroupChat: true,
      groupAdmin: req.body.currentUserId,
    });

    // Populate group chat data
    const fullGroupChat = await chatModel
      .findOne({ _id: groupChat._id })
      .populate("users", "-password")
      .populate("groupAdmin", "-password");

    // Send response with group chat data
    res.status(200).send({
      success: true,
      message: "Group chat created successfully",
      data: fullGroupChat,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error creating group chat",
      success: false,
      error: error.message,
    });
  }
};

//======================= if you want to change the group chat name =====
export const renameGroupController = async (req, res) => {
  try {
    const { chatId, chatName } = req.body;
    const updatedChat = await chatModel
      .findByIdAndUpdate(chatId, { chatName }, { new: true })
      .populate("users", "-password")
      .populate("groupAdmin", "-password");

    if (!updatedChat) {
      return res.status(404).send({
        message: "Chat Not Found",
        success: false,
      });
    } else {
      res.status(200).send({
        success: true,
        message: "Chat renamed successfully",
        data: updatedChat,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error renaming chat",
      success: false,
      error,
    });
  }
};
//========================= if you want to add user to a group chat ============
export const addUserGroupController = async (req, res) => {
  try {
    const { chatId, userId } = req.body;

    const added = await chatModel
      .findByIdAndUpdate(chatId, { $push: { users: userId } }, { new: true })
      .populate("users", "-password")
      .populate("groupAdmin", "-password");

    if (!added) {
      return res.status(404).send({
        message: "Chat Not Found",
        success: false,
      });
    } else {
      res.status(200).send({
        success: true,
        message: "User added to group successfully",
        data: added,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error adding user to group",
      success: false,
      error,
    });
  }
};

//================ Remove user from the group ============
export const removeUserGroupController = async (req, res) => {
  try {
    const { chatId, userId } = req.body;

    // Check if the requester is admin
    // (Note: This check is missing in the original code,
    // you should add it according to your requirements)

    const removed = await chatModel
      .findByIdAndUpdate(chatId, { $pull: { users: userId } }, { new: true })
      .populate("users", "-password")
      .populate("groupAdmin", "-password");

    if (!removed) {
      return res.status(404).send({
        message: "Chat Not Found",
        success: false,
      });
    } else {
      res.status(200).send({
        success: true,
        message: "User removed from group successfully",
        data: removed,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: "Error removing user from group",
      success: false,
      error,
    });
  }
};
