import jobModel from "../Models/jobModel.js";

export const createJobController = async (req, res) => {
  try {
    const {
      jobTitle,
      jobDescription,
      hotelName,
      hotel,
      location,
      jobType,
      shift,
      jobCategory,
      requiredSkills,
      experience,
      education,
      salary,
      jobStatus,
    } = req.body;
    const jobs = new jobModel({
      jobTitle,
      jobDescription,
      hotelName,
      hotel,
      location,
      jobType,
      shift,
      jobCategory,
      requiredSkills,
      experience,
      education,
      salary,
      jobStatus,
    });
    await jobs.save();
    res.status(200).send({
      success: true,
      message: "Job created Successfully",
      jobs,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while creating Job",
      error,
    });
  }
};

//======================= Getting all jobs =======================

export const AllJobController = async (req, res) => {
  try {
    const jobs = await jobModel.find();
    res.status(200).send({
      success: true,
      message: "Fetch all Jobs Successfully",
      data: jobs,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while Getting all jobs",
      error,
    });
  }
};

// ================ Getting Single job data ===============

export const singleJobController = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await jobModel.findById(id);
    if (!job) {
      return res.status(404).send({
        success: false,
        message: "Fetch not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Single Job Fetch Successfully",
      data: job,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Something went wrong",
    });
  }
};

//======================== Update Job Controller ================

export const updateJobController = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    const job = await jobModel.findByIdAndUpdate(id, updateData, { new: true });
    if (!job) {
      return res.status(404).send({
        success: false,
        message: "Job not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Job updated successfully",
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Something went wrong",
    });
  }
};

// ================ Delete Job  ========

export const deleteJobController = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await jobModel.findByIdAndDelete(id);
    if (!job) {
      return res.status(404).send({
        success: false,
        message: "Job not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Job deleted successfully",
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Something went wrong",
      error,
    });
  }
};
