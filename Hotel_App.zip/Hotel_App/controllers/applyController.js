import applyModel from "../Models/applyModel.js";

//============ Submittting user application ===========
export const applyController = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      address,
      age,
      availability,
      coverLetter,
      education,
      jobId,
      jobTitle,
    } = req.body;
    const applyData = new applyModel({
      name,
      email,
      phone,
      address,
      age,
      availability,
      coverLetter,
      education,
      jobId,
      jobTitle,
    });
    await applyData.save();
    res.status(200).send({
      success: true,
      message: "Apply Done successfully",
      data: applyData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({ success: false, message: "Error in Apply", error });
  }
};

//============= Getting user application that are in pending ==========

export const getPendingApplicationsController = async (req, res) => {
  try {
    const applications = await applyModel.find({ status: "pending" });
    res.status(200).send({
      success: true,
      message: "Fetch Pending User Applications Successfully",
      data: applications,
      count: applications.length,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error in Getting Pending User Applications",
      error,
    });
  }
};
//------------- Getting accepted application in staff page ------------
export const getAcceptedApplicationsController = async (req, res) => {
  try {
    const applications = await applyModel.find({ status: "accepted" });
    res.status(200).send({
      success: true,
      message: "Fetch Accepted User Applications Successfully",
      data: applications,
      count: applications.length,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error in Getting Accepted User Applications",
      error,
    });
  }
};

//====================== Changing a status of application ----------------

export const approveStatusController = async (req, res) => {
  const { id } = req.params;
  try {
    const application = await applyModel.findByIdAndUpdate(
      id,
      { status: "accepted" },
      { new: true }
    );
    if (application) {
      res
        .status(200)
        .send({ success: true, message: "Application approved successfully" });
    } else {
      res
        .status(404)
        .send({ success: false, message: "Application not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send({ success: false, message: "Something went wrong" });
  }
};

export const deleteController = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await applyModel.findByIdAndDelete(id);
    if (!application) {
      return res
        .status(404)
        .send({ success: false, message: "Application not found" });
    }

    res.status(200).send({
      success: true,
      message: "Delete Application Successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error while Delete Application",
      error,
    });
  }
};
