import express from "express";
import authMiddleware from "./../middlewares/authMiddleware.js";
import {
  AllJobController,
  createJobController,
  deleteJobController,
  singleJobController,
  updateJobController,
} from "../controllers/jobController.js";
const router = express.Router();

// ==== Posting job ====

router.post("/create-job", authMiddleware, createJobController);
//====== Get all jobs ===============
router.get("/get-jobs", authMiddleware, AllJobController);
//======== Getting single job ========
router.get("/single-job/:id", authMiddleware, singleJobController);
//============ Update job ========
router.put("/update-job/:id", authMiddleware, updateJobController);
// ================ Delete job ====

router.delete("/delete-job/:id", authMiddleware, deleteJobController);
export default router;
