import express from "express";
import authMiddleware from "../middlewares/authMiddleware.js";
import multer from "multer";
import {
  createController,
  getAllHotelController,
} from "../controllers/hotelController.js";

const router = express.Router();

//============= Hotel Creation ===========
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./client/src/hotel/");
    array: true;
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now();
    const fileName = file.originalname.replace(/\s+/g, ""); // remove spaces
    cb(null, uniqueSuffix + fileName);
  },
});
const upload = multer({ storage: storage });
router.post(
  "/create-hotel",
  authMiddleware,
  upload.array("images", 12),
  createController
);

//================== Getting Hotels ====================
router.get("/get-hotel", authMiddleware, getAllHotelController);

export default router;
