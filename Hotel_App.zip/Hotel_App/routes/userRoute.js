import exporess from "express";
import {
  loginController,
  registerController,
  authController,
  getAllGuestController,
  deleteUserController,
  singleUserController,
  searchUserController,
} from "../controllers/userController.js";
import authMiddleware from "../middlewares/authMiddleware.js";
const router = exporess.Router();

// =========== routers ==========
// ------ post // register ----------
router.post("/register", registerController);
// ------ post // login ---------
router.post("/login", loginController);

//Auth || POST
router.post("/getUserData", authMiddleware, authController);

//==== Getting all user data that are fetch in guest page =====
router.post("/All-user", authMiddleware, getAllGuestController);
//============ Getting single user details ===========
router.get("/get-user/:userId", authController, singleUserController);
// ======== Search user ============
router.get("/search-user", authMiddleware, searchUserController);
//=========== Deleting user ==============
router.delete("/delete-user/:id", authMiddleware, deleteUserController);

export default router;
