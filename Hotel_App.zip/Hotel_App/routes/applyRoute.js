import express from "express";
import authMiddlereware from "./../middlewares/authMiddleware.js";
import {
  applyController,
  approveStatusController,
  deleteController,
  getAcceptedApplicationsController,
  getPendingApplicationsController,
} from "../controllers/applyController.js";
const router = express.Router();

router.post("/job-apply", authMiddlereware, applyController);
//========== Get application in jobs whose status is in pending ========

router.get(
  "/get-pending-applications",
  authMiddlereware,
  getPendingApplicationsController
);

//========== Get application in staff page whose status is in accepted ========
router.get(
  "/get-accepted-applications",
  authMiddlereware,
  getAcceptedApplicationsController
);
//========== Deleting staff application ===============
router.delete("/delete-application/:id", authMiddlereware, deleteController);

//============= Deleteing user submitted application ==========
router.delete("/delete-application/:id", authMiddlereware, deleteController);
//================= fetching accepted status application ================
router.put(
  "/approve-application/:id",
  authMiddlereware,
  approveStatusController
);

export default router;
