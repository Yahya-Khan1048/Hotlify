import express from "express";
import authMiddlereware from "./../middlewares/authMiddleware.js";
import {
  acceptBooking,
  createBookingController,
  deleteBookingController,
  getAllBookingController,
  getAllUserBookingController,
  rejectBooking,
} from "../controllers/bookingController.js";

const router = express.Router();

// ========== Booking room from user side ==============

router.post("/booking-room", authMiddlereware, createBookingController);
router.get("/all-booking", authMiddlereware, getAllBookingController);
router.delete("/delete-booking/:id", authMiddlereware, deleteBookingController);

//========== Manipulating Data of Booking from admin side ===========
router.get("/all-userbooking", authMiddlereware, getAllUserBookingController);
router.post("/accept-booking/:id", authMiddlereware, acceptBooking);
router.post("/reject-booking/:id", authMiddlereware, rejectBooking);

export default router;
