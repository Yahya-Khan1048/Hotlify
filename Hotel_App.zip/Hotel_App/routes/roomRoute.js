import express from "express";
import {
  allRoomController,
  bookRoomController,
  createRoomController,
  deleteRoomController,
  getAllRoomController,
  getSingleRoom,
  getUserRoomController,
  releaseRoomController,
  searchRoomController,
  updateRoomController,
} from "../controllers/roomController.js";
import authMiddleware from "../middlewares/authMiddleware.js";
import multer from "multer";

const router = express.Router();

// ===== Room Creation || Post =========
// router.post("/create-rooms", createRoomController);

//====== Getting rooom || Get =========
// router.get("/allroom", getAllRoomController);

//========= Getting Single room \\ Get  ========

router.get("/single-room/:id", getSingleRoom);

//======== updating room detals ============
router.put("/update-room/:id", updateRoomController);

//========== Searching room ============

router.get("/search-room/:keyword", searchRoomController);

//======== Deleting room ==============

router.delete("/delete-room/:id", deleteRoomController);

///    ============ Passing room data ================

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./client/src/images/");
    array: true;
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now();
    const fileName = file.originalname.replace(/\s+/g, ""); // remove spaces
    cb(null, uniqueSuffix + fileName);
  },
});

const upload = multer({ storage: storage });
// ================ Upload room details ================
router.post(
  "/create-rooms",
  authMiddleware,
  upload.array("images", 12),
  createRoomController
);
// ============= change status of room to Booking =====
router.post("/book-room/:id", authMiddleware, bookRoomController);
// ============= change status of room to release =====
router.post("/release-room/:id", authMiddleware, releaseRoomController);

//================== Getting rooms ====================
router.get("/get-rooms/:id", authMiddleware, getAllRoomController);

//=================== USer Routes ======================
// Getting room related to hotel id
router.get("/get-rooms/:id", authMiddleware, getUserRoomController);

//==================  admin routes =======================
router.get("/rooms", authMiddleware, allRoomController);
export default router;
