import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout/Layout";
import { Image } from "react-bootstrap";
import axios from "axios";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { message } from "antd";
import { Link } from "react-router-dom";
const JobDetails = () => {
  const { user } = useSelector((state) => state.user);
  const { id } = useParams();
  const [details, setDetails] = useState();
  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const res = await axios.get(`/api/v1/job/single-job/${id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        if (res.data.success) {
          setDetails(res.data.data);
        } else {
          message.error(res.data.message);
        }
      } catch (error) {
        message.error("Something went wrong");
      }
    };
    fetchJobDetails();
  }, [id]);
  return (
    <Layout>
      <div className="container row mt-5 mb-5">
        <h1 style={{ paddingLeft: "63px", marginLeft: "20px" }}>
          Job Specifications
        </h1>
        <div className="row mt-5" style={{ paddingLeft: "60px" }}>
          <div
            className="col-md-6"
            style={{ paddingLeft: "20px", marginLeft: "20px" }}
          >
            <Image
              src="/images/details_2.jpg"
              alt="Job Image"
              className="img-fluid"
              style={{ maxWidth: "100%", maxHeight: "80%" }}
            />
          </div>
          <div
            className="col-md-5"
            style={{ paddingLeft: "20px", marginLeft: "-60px" }}
          >
            <div className="card">
              {details && (
                <>
                  <div
                    className="card-body"
                    style={{
                      background: " #00203fff",
                      border: "1px solid #adefd1ff",
                    }}
                  >
                    <h3 className="card-title">{details.jobTitle}</h3>
                    <p className="card-text">
                      <strong>Hotel: </strong>
                      {details.hotelName}
                    </p>
                    <p className="card-text">
                      <strong>Description: </strong>
                      {details.jobDescription}
                    </p>
                    <p className="card-text">
                      <strong>Duty: </strong>
                      {details.jobType}
                    </p>
                    <p className="card-text">
                      <strong>Shift: </strong>
                      {details.shift}
                    </p>
                    <p className="card-text">
                      <strong>Location: </strong>
                      {details.location}
                    </p>
                    <h3 className="card-title">Job Requirements</h3>
                    <div className="row">
                      <div className="col-md-12">
                        <p>
                          <strong>Requirement 1:</strong>{" "}
                          {details.requiredSkills}
                        </p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-12">
                        <p>
                          <strong>Requirement 2:</strong> {details.experience}
                        </p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-12">
                        <p>
                          <strong>Requirement 3:</strong> {details.education}
                        </p>
                      </div>
                    </div>
                    <p>
                      <strong>Salary</strong> $:{details.salary}
                    </p>
                    {!user.admin && (
                      <Link to={`/JobApply/${details._id}/${details.jobTitle}`}>
                        <button className="btn btn-primary" type="button">
                          Apply Now
                        </button>
                      </Link>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default JobDetails;
