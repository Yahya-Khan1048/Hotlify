import React, { useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";
const JobApply = () => {
  const { id, title } = useParams(); //   accessing to the job id and job title
  const navigate = useNavigate();
  // console.log(id, title);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [age, setAge] = useState("");
  const [availability, setAvailability] = useState("");
  const [coverLetter, setCoverLetter] = useState("");
  const [education, setEducation] = useState("");
  const [jobId, setJobId] = useState(id);
  const [jobTitle, setJobTitle] = useState(title);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !name ||
      !email ||
      !phone ||
      !address ||
      !age ||
      !availability ||
      !coverLetter ||
      !education
    ) {
      message.error("Please all the input fields");
      return;
    }
    try {
      const res = await axios.post(
        "/api/v1/apply/job-apply",
        {
          name,
          email,
          phone,
          address,
          age,
          availability,
          coverLetter,
          education,
          jobId: id,
          jobTitle: title,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/user/careers");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <h1 className="mb-3 pb-4">Apply Form for Job</h1>
        <form onSubmit={handleSubmit}>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Name">Name</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Name"
                  placeholder="Enter name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Email">Email</label>
                <input
                  type="email"
                  className="form-control form-control-lg"
                  id="Email"
                  placeholder="Enter email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Phone">Phone</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Phone"
                  placeholder="Enter phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Address">Address</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Address"
                  placeholder="Enter address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Age">Age</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="Age"
                  placeholder="Enter age"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Availability">Availability</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Availability"
                  placeholder="Enter availability"
                  value={availability}
                  onChange={(e) => setAvailability(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-12">
              <div className="form-group">
                <label htmlFor="CoverLetter">Cover Letter</label>
                <textarea
                  className="form-control form-control-lg"
                  id="CoverLetter"
                  placeholder="Enter cover letter"
                  value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-12">
              <div className="form-group">
                <label htmlFor="Education">Education</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Education"
                  placeholder="Enter education"
                  value={education}
                  onChange={(e) => setEducation(e.target.value)}
                  style={{
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="d-grid col-md-4 mt-4">
            <button className="btn btn-primary" type="submit">
              Submit Application
            </button>
          </div>
          <input type="hidden" name="jobId" value={id} />
          <input type="hidden" name="jobTitle" value={title} />
        </form>
      </div>
    </Layout>
  );
};

export default JobApply;
