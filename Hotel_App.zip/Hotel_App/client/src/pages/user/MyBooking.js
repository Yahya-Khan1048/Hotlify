import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import axios from "axios";
import { message } from "antd";

const MyBooking = () => {
  const [bookings, setAllBookings] = useState([]);

  const getAllBookings = async () => {
    try {
      const res = await axios.get(`/api/v1/booking/all-booking`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllBookings(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getAllBookings();
  }, []);

  const handleRemoveBooking = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/booking/delete-booking/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        getAllBookings();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  //   const handleShowStatus = () => {};

  return (
    <Layout>
      <>
        <h1 className="text-center p-3"> Booking Overview</h1>

        <div className="row p-2 m-2">
          {bookings.map((booking) => (
            <div
              key={booking._id}
              className="col-md-5 row mx-auto m-3 border shadow p-2"
            >
              <div className="col-md-6">
                <h3>Booking Details</h3>
                <hr />
                <h4>Person: {booking.name}</h4>
                <p>
                  <b> Check-in:</b>{" "}
                  {new Date(booking.checkInDate).toLocaleDateString()}
                </p>
                <p>
                  <b> Check-out:</b>
                  {new Date(booking.checkOutDate).toLocaleDateString()}
                </p>
                <p>
                  {" "}
                  <b>Number of guests:</b> {booking.numberOfGuests}
                </p>
                <p>
                  {" "}
                  <b>Address:</b> {booking.address}
                </p>
                <p>
                  <b> Booked on:</b>{" "}
                  {new Date(booking.createdAt).toLocaleDateString()}
                </p>
              </div>
              <div className=" row gap-2 col-6 mx-auto p-5 mt-5">
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleRemoveBooking(booking._id)}
                >
                  Remove Booking
                </button>
                <button className="btn btn-primary btn-sm">
                  {booking.status}
                </button>
              </div>
            </div>
          ))}
        </div>
      </>
    </Layout>
  );
};

export default MyBooking;
