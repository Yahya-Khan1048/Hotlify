import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import { Image, message } from "antd";
import { Link } from "react-router-dom";
import axios from "axios";

const AvaliableJobs = () => {
  const [job, setJob] = useState([]);
  const getJob = async () => {
    try {
      const res = await axios.get(`/api/v1/job/get-jobs`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setJob(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  useEffect(() => {
    getJob();
  }, []);
  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <div className="container">
          <div className="col-md-12 d-flex justify-content-between align-items-center">
            <div className="col-md-6">
              <h1>Careers At Our Hotel</h1>
            </div>
          </div>
        </div>
        <div className="row p-3">
          {job && job.length > 0 ? (
            job.map((job, index) => (
              <div className="col-md-4 mb-4">
                <div
                  className="card"
                  style={{
                    width: "24rem",
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <Image
                    src="/images/Good.jpg"
                    alt="Job Image"
                    style={{ width: "382px", height: "270px" }}
                  />

                  <div className="card-body">
                    <div className="d-flex justify-content-between">
                      <h5 className="card-title"> {job.jobTitle}</h5>
                    </div>
                    <p className="card-text">
                      <strong>Location:</strong> {job.location}
                    </p>
                    <p className="card-text">
                      <strong>Salary:</strong> $:{job.salary}
                    </p>
                    <p className="card-text">
                      <strong>Job Type:</strong> {job.jobType}
                    </p>
                    <Link to={`/JobDetails/${job._id}`}>
                      <div className="d-grid gap-2 col-12 mx-auto">
                        <button className="btn btn-primary" type="button">
                          Job Details
                        </button>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <h1>No Job Exists</h1>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default AvaliableJobs;
