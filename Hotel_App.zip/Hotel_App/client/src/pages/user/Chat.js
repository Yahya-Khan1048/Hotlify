import React from "react";
import Layout from "../../components/Layout/Layout";

const Chat = () => {
  return (
    <Layout>
      <h1>Wellcome to chat</h1>
    </Layout>
  );
};

export default Chat;
