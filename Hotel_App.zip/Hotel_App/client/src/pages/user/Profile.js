import React from "react";
import Layout from "../../components/Layout/Layout";
import UserMenu from "../../components/Layout/userMenu";
// import { message } from "antd";
import { useSelector } from "react-redux";
// import axios from "axios";
const Profile = () => {
  // const [user, setUser] = useState({});
  const { user } = useSelector((state) => state.user);
  // const getUser = async () => {
  //   try {
  //     const userId = localStorage.getItem("userId");
  //     const res = await axios.get(`/api/v1/user/get-user/${userId}`, {
  //       headers: {
  //         Authorization: `Bearer ${localStorage.getItem("token")}`,
  //       },
  //     });
  //     if (res.data.success) {
  //       setUser(res.data.data);
  //     } else {
  //       message.error(res.data.message);
  //     }
  //   } catch (error) {
  //     message.error("Something went wrong");
  //   }
  // };

  // useEffect(() => {
  //   getUser();
  // }, []);

  return (
    <Layout>
      <>
        <div className="container col-md-12 m-3 p-4 gap-5">
          <div className="col-md-4 ml-4">
            <UserMenu />
          </div>
          <div className="col-md-4">
            <h1 className="">Profile Details</h1>
            <div className="card-body border rounded">
              <div className="d-flex gap-5 pl-3">
                <h3 className="card-title">Name:</h3>
                <p className="pt-2"> {user.name}</p>
              </div>
              <div className="d-flex gap-5 pl-3">
                <h3 className="cart-title">Email: </h3>
                <p className="card-text pt-2"> {user.email}</p>
              </div>
              <div className="d-flex gap-5 pl-3">
                <h3 className="cart-title">Language: </h3>
                <p className="card-text pt-2"> {user.language}</p>
              </div>
            </div>
          </div>
          <div className="col-md-3"></div>
        </div>
      </>
    </Layout>
  );
};

export default Profile;
