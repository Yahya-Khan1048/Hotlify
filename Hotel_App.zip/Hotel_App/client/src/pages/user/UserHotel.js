import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import axios from "axios";
import { Link } from "react-router-dom";

import { message } from "antd";
const UserHotel = () => {
  const [allHotel, setAllHotel] = useState([]);
  //======== Fetching all room data ==========
  const getHotel = async () => {
    try {
      const res = await axios.get(`/api/v1/hotel/get-hotel`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllHotel(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getHotel();
  }, []);

  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <div className="container">
          <div className="col-md-12 d-flex justify-content-between align-items-center">
            <div className="col-md-6">
              <h1>All Avaliable Hotel</h1>
            </div>
          </div>
        </div>

        <div className="row p-3">
          {allHotel &&
            allHotel.map((hotel, index) => (
              <div className="col-md-4 mb-4">
                <div
                  className="card"
                  style={{
                    width: "24rem",
                    background: " #00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  {/* images */}
                  <div
                    id={`carouselExampleControls-${index}`}
                    className="carousel slide"
                    data-bs-ride="carousel"
                  >
                    <div className="carousel-inner">
                      {hotel.images.map((image, imgIndex) => (
                        <div
                          className={`carousel-item ${
                            imgIndex === 0 ? "active" : ""
                          }`}
                        >
                          <img
                            src={require(`../../hotel/${image}`)}
                            class="d-block w-100"
                            alt="..."
                            style={{
                              width: "100%",
                              height: "200px",
                              objectFit: "cover",
                            }}
                          />
                        </div>
                      ))}
                    </div>
                    <button
                      class="carousel-control-prev"
                      type="button"
                      data-bs-target={`#carouselExampleControls-${index}`}
                      data-bs-slide="prev"
                      style={{
                        borderRadius: "10%",
                        height: "40px",
                        background: " #00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                        width: "40px",
                        padding: "5px",
                        position: "absolute",
                        top: "70%",
                        transform: "translateY(-50%)",
                        marginLeft: "20px",
                      }}
                    >
                      <span
                        class="carousel-control-prev-icon"
                        aria-hidden="true"
                      ></span>
                      <span class="visually-hidden">Previous</span>
                    </button>

                    <button
                      class="carousel-control-next"
                      type="button"
                      data-bs-target={`#carouselExampleControls-${index}`}
                      data-bs-slide="next"
                      style={{
                        borderRadius: "10%",
                        height: "40px",
                        background: " #00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                        width: "40px",
                        padding: "5px",
                        position: "absolute",
                        top: "70%",
                        transform: "translateY(-50%)",
                        marginRight: "20px",
                      }}
                    >
                      <span
                        class="carousel-control-next-icon"
                        aria-hidden="true"
                      ></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
                  {/* images end */}
                  <div className="card-body">
                    <div className="d-flex  justify-content-between">
                      <h5 className="card-title">{hotel.name}</h5>
                    </div>
                    <p className="card-text">{hotel.address}</p>
                    <Link to={`/rooms/${hotel._id}`}>
                      <div className="d-grid gap-2 col-12 mx-auto">
                        <button className="btn btn-primary" type="button">
                          Details
                        </button>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </Layout>
  );
};

export default UserHotel;
