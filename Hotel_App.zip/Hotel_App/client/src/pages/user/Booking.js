import React, { useState } from "react";
import Layout from "../../components/Layout/Layout";
import axios from "axios";
import { message } from "antd";
import { useParams } from "react-router-dom";
const Booking = () => {
  const { id } = useParams();

  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [phoneNumber, setPhoneNumber] = useState();
  const [checkInDate, setCheckInDate] = useState();
  const [checkOutDate, setCheckOutDate] = useState();
  const [numberOfGuests, setNumberOfGuests] = useState();
  const [address, setAddress] = useState();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !name ||
      !email ||
      !phoneNumber ||
      !checkInDate ||
      !checkOutDate ||
      !numberOfGuests ||
      !address
    ) {
      message.error("Please fill in all fields");
      return;
    }
    try {
      const userId = localStorage.getItem("userId");
      // const token = localStorage.getItem("token");
      const res = await axios.post(
        "/api/v1/booking/booking-room",
        {
          name,
          email,
          phoneNumber,
          checkInDate,
          checkOutDate,
          numberOfGuests,
          address,
          userId,
          roomId: id, // changed from bookingId to roomId
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      console.log("result", res);

      if (res.data.success) {
        message.success(res.data.message);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <h1 style={{ marginTop: "20px", marginBottom: "20px" }}>
          Enter Your Personal <br /> Information
        </h1>
        <div className="row">
          <div className="col-md-8">
            <form onSubmit={handleSubmit} style={{ marginTop: "30px" }}>
              <div className="row" style={{ marginBottom: "20px" }}>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="name">Name</label>
                    <input
                      type="text"
                      className="form-control form-control-lg"
                      id="name"
                      placeholder="Enter your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                      type="email"
                      className="form-control form-control-lg"
                      id="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="row" style={{ marginBottom: "20px" }}>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="checkInDate">Check-in Date</label>
                    <input
                      type="date"
                      className="form-control form-control-lg"
                      id="checkInDate"
                      value={checkInDate}
                      onChange={(e) => setCheckInDate(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="checkOutDate">Check-out Date</label>
                    <input
                      type="date"
                      className="form-control form-control-lg"
                      id="checkOutDate"
                      value={checkOutDate}
                      onChange={(e) => setCheckOutDate(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="row" style={{ marginBottom: "20px" }}>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="phoneNumber">Phone Number</label>
                    <input
                      type="number"
                      className="form-control form-control-lg"
                      id="phoneNumber"
                      placeholder="Enter your phone number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="numberOfGuests">Number of Guests</label>
                    <input
                      type="number"
                      className="form-control form-control-lg"
                      id="numberOfGuests"
                      placeholder="Enter number of guests"
                      value={numberOfGuests}
                      onChange={(e) => setNumberOfGuests(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="row" style={{ marginBottom: "20px" }}>
                <div className="col-md-12">
                  <div className="form-group">
                    <label htmlFor="address">Address</label>
                    <input
                      type="text"
                      className="form-control form-control-lg"
                      id="address"
                      placeholder="Enter your address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      required
                      style={{
                        background: "#00203fff",
                        color: "#adefd1ff",
                        border: "1px solid #adefd1ff",
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="d-grid col-md-4 mt-4">
                <button className="btn btn-primary" type="submit">
                  Submit Details
                </button>
              </div>
            </form>
          </div>
          <div className="col-md-4 justify-content-center ">
            <div>
              <h1 className="text-center">Transaction details</h1>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Booking;
