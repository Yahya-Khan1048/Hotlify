import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import UserMenu from "../../components/Layout/userMenu";
import axios from "axios";
import { message } from "antd";
const Application = () => {
  const [userApplication, setUserApplication] = useState([]);

  const getApplication = async () => {
    try {
      const res = await axios.get(`/api/v1/apply/get-pending-applications`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setUserApplication(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  //============ Delete Record ===========
  const deleteApplication = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/apply/delete-application/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success("Application deleted successfully");
        getApplication(); // Call getApplication to refresh the list
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getApplication();
  }, []);

  return (
    <Layout>
      <>
        <div className="container  m-3 p-4">
          <div className="row col-md-4 ml-4">
            <UserMenu />
          </div>
          <div className="col-md-7 mx-auto">
            <h1>User Applications</h1>
            {userApplication.map((application, index) => (
              <div
                key={index}
                className="card col-md-12 row mx-auto mt-3 border shadow p-4"
                style={{
                  background: " #00203fff",
                  color: "#adefd1ff",
                  border: "1px solid #adefd1ff",
                }}
              >
                <div className="row">
                  <div className="col-md-12">
                    <h2>{application.jobTitle}</h2>
                  </div>

                  <div className="col-md-6">
                    <div className="application-details m-3">
                      <p>
                        <b>Name:</b> {application.name}
                      </p>
                      <p>
                        <b>Address:</b> {application.address}
                      </p>
                      <p>
                        <b>Age:</b> {application.age}
                      </p>
                      <p>
                        <b>Availability:</b> {application.availability}
                      </p>
                      <p>
                        <b>Cover Letter:</b> {application.coverLetter}
                      </p>
                      <p>
                        <b>Education:</b> {application.education}
                      </p>
                    </div>
                  </div>
                  <div className="col-md-2 offset-md-3 actions">
                    <div className="justify-content-center mt-4 pt-3">
                      <button className="btn btn-primary mb-3">
                        {application.status}
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => deleteApplication(application._id)}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </>
    </Layout>
  );
};

export default Application;
