import React from "react";
import Layout from "../components/Layout/Layout";

const HomePage = () => {
  return (
    <Layout>
      <>
        <div
          id="carouselExampleCaptions"
          className="carousel slide"
          data-bs-ride="carousel"
        >
          <div className="carousel-indicators">
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to={0}
              className="active"
              aria-current="true"
              aria-label="Slide 1"
            />
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to={1}
              aria-label="Slide 2"
            />
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to={2}
              aria-label="Slide 3"
            />
          </div>
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img
                src="/images/ree.jpg"
                className="d-block w-100"
                alt="..."
                style={{ height: "700px" }}
              />
              <div
                className="carousel-caption d-none d-md-block text-center"
                style={{ top: "80%", transform: "translateY(-50%)" }}
              >
                <h1>Versatile Event Spaces</h1>
                <h3>
                  Our hotel features flexible event spaces, perfect for hosting
                  conferences, weddings, and other special occasions
                </h3>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src="/images/ra.jpg"
                className="d-block w-100"
                alt="..."
                style={{ height: "700px" }}
              />
              <div
                className="carousel-caption d-none d-md-block text-center"
                style={{ top: "80%", transform: "translateY(-50%)" }}
              >
                <h1>Relaxing Atmosphere</h1>
                <h3>
                  Unwind in our serene lobby lounge, offering a peaceful retreat
                  from the hustle and bustle of the city
                </h3>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src="/images/pics_1.jpg"
                className="d-block w-100"
                alt="..."
                style={{ height: "700px" }}
              />
              <div
                className="carousel-caption d-none d-md-block text-center"
                style={{ top: "80%", transform: "translateY(-50%)" }}
              >
                <h1 className="position-relative top-10">
                  Luxurious Accommodations
                </h1>
                <h3>
                  Our hotel offers lavish rooms and suites, designed to provide
                  unparalleled comfort and relaxation
                </h3>
              </div>
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev"
          >
            <span
              className="carousel-control-prev-icon"
              aria-hidden="true"
              style={{ borderRadius: "50%" }}
            />
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next"
          >
            <span
              className="carousel-control-next-icon"
              aria-hidden="true"
              style={{ borderRadius: "50%" }}
            />
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </>
    </Layout>
  );
};

export default HomePage;
