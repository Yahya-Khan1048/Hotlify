import React, { useState } from "react";
import "./Register.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { message } from "antd";
import { useDispatch } from "react-redux";
import { showLoading, hideLoading } from "../redux/features/alertSlice";
import { NavLink } from "react-router-dom";
const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [language, setLanguage] = useState("");

  // ======== Form function ========
  const navigate = useNavigate();
  const dispatch = useDispatch();
  //form handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      dispatch(showLoading());
      const res = await axios.post("/api/v1/user/register", {
        name,
        email,
        password,
        language,
      });
      dispatch(hideLoading());
      if (res.data.success) {
        message.success("Register Successfully!");
        navigate("/login");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      dispatch(hideLoading());
      console.log(error);
      message.error("Something Went Wrong");
    }
  };
  return (
    <>
      <div className="register-container">
        <div className="register-form">
          <div className="form-section">
            <h1>Registration</h1>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                value={name}
                placeholder="Enter Name"
                name="username"
                onChange={(e) => setName(e.target.value)}
                required
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                name="email"
                required
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="form-control"
                id="exampleInputPassword1"
                placeholder="Enter Your password"
                required
                style={{
                  background: "#00203fff",
                  color: "#adefd1ff",
                }}
              />
              <input
                type="text"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="form-control"
                id="exampleInputPassword1"
                placeholder="Enter Your Favourite Language"
                required
                style={{
                  background: "#00203fff",
                  color: "#adefd1ff",
                }}
              />
              <div className="form-group">
                <input type="checkbox" name="terms" id="terms" required />
                <label htmlFor="terms">
                  I agree to all statements in{" "}
                  <NavLink to={"/register"}>Terms of Service</NavLink>
                </label>
              </div>
              <button type="submit">Register</button>
            </form>
          </div>
          <div className="image-section">
            <img src="/images/register.jpg" alt="Sign up" />
            <NavLink className="login-link" to="/login">
              I am already a member
            </NavLink>
          </div>
        </div>
      </div>
    </>
  );
};

export default Register;
