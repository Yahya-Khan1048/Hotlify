import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const EditRoom = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [updateRoom, setUpdateRoom] = useState({
    name: "",
    pricePerNight: "",
    description: "",
    address: "",
    guestCapacity: "",
    numOfBeds: "",
    internet: "",
    breakfast: "",
    ac: "",
    petAllowed: "",
    roomCleaning: "",
    category: "",
    images: [],
  });

  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchRoomDetails = async () => {
      try {
        const res = await axios.get(`/api/v1/rooms/single-room/${id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        if (res.data.success) {
          const roomData = res.data.data;
          setUpdateRoom({
            ...roomData,

            // if the API response has internet: true, it will be converted to "yes" and populated in the form.
            // If the API response has internet: false, it will be converted to "no" and populated in the form.
            internet: roomData.internet ? "yes" : "no",
            breakfast: roomData.breakfast ? "yes" : "no",
            ac: roomData.ac ? "yes" : "no",
            petAllowed: roomData.petAllowed ? "yes" : "no",
            roomCleaning: roomData.roomCleaning ? "yes" : "no",
          });
          setImages(roomData.images);
        } else {
          message.error(res.data.message);
          navigate("/admin/room");
        }
      } catch (error) {
        message.error("Something went wrong");
      }
    };
    fetchRoomDetails();
  }, [id, navigate]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    images.forEach((image) => {
      formData.append("images", image);
    });
    formData.append("name", updateRoom.name);
    formData.append("pricePerNight", updateRoom.pricePerNight);
    formData.append("description", updateRoom.description);
    formData.append("address", updateRoom.address);
    formData.append("guestCapacity", updateRoom.guestCapacity);
    formData.append("numOfBeds", updateRoom.numOfBeds);
    formData.append("internet", updateRoom.internet);
    formData.append("breakfast", updateRoom.breakfast);
    formData.append("ac", updateRoom.ac);
    formData.append("petAllowed", updateRoom.petAllowed);
    formData.append("roomCleaning", updateRoom.roomCleaning);
    formData.append("category", updateRoom.category);
    const userId = localStorage.getItem("userId");
    if (userId) {
      formData.append("userId", userId);
    }
    try {
      const updateData = { ...updateRoom };
      delete updateData._id; // Remove _id from the object
      const res = await axios.put(
        `/api/v1/rooms/update-room/${id}`,
        updateData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/hotels");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  const handleImageChange = (e) => {
    const newImages = Array.from(e.target.files);
    setImages([...images, ...newImages]);
  };

  //   const handleChange = (e) => {
  //     setUpdateRoom({ ...updateRoom, [e.target.name]: e.target.value });
  //   };
  const setName = (value) => {
    setUpdateRoom({ ...updateRoom, name: value });
  };

  const setPricePerNight = (value) => {
    setUpdateRoom({ ...updateRoom, pricePerNight: value });
  };
  const setDescription = (value) => {
    setUpdateRoom({ ...updateRoom, description: value });
  };
  const setAddress = (value) => {
    setUpdateRoom({ ...updateRoom, address: value });
  };
  const setGuestCapacity = (value) => {
    setUpdateRoom({ ...updateRoom, guestCapacity: value });
  };
  const setNumOfBeds = (value) => {
    setUpdateRoom({ ...updateRoom, numOfBeds: value });
  };
  const setInternet = (value) => {
    setUpdateRoom({ ...updateRoom, internet: value });
  };
  const setBreakfast = (value) => {
    setUpdateRoom({ ...updateRoom, breakfast: value });
  };
  const setAc = (value) => {
    setUpdateRoom({ ...updateRoom, ac: value });
  };
  const setPetAllowed = (value) => {
    setUpdateRoom({ ...updateRoom, petAllowed: value });
  };
  const setRoomCleaning = (value) => {
    setUpdateRoom({ ...updateRoom, roomCleaning: value });
  };
  const setCategory = (value) => {
    setUpdateRoom({ ...updateRoom, category: value });
  };
  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <form onSubmit={handleUpdate}>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="name">Room Name</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="name"
                  placeholder="Enter room name"
                  value={updateRoom.name}
                  onChange={(e) => setName(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="pricePerNight">Price Per Night</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="pricePerNight"
                  placeholder="Enter price per night"
                  value={updateRoom.pricePerNight}
                  onChange={(e) => setPricePerNight(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="description">Description</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="description"
                  placeholder="Enter room description"
                  value={updateRoom.description}
                  onChange={(e) => setDescription(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="address">Address</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="address"
                  placeholder="Enter address"
                  value={updateRoom.address}
                  onChange={(e) => setAddress(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="guestCapacity">Guest Capacity</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="guestCapacity"
                  placeholder="Enter guest capacity"
                  value={updateRoom.guestCapacity}
                  onChange={(e) => setGuestCapacity(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="numOfBeds">Number of Beds</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="numOfBeds"
                  placeholder="Enter number of beds"
                  value={updateRoom.numOfBeds}
                  onChange={(e) => setNumOfBeds(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="internet">Internet</label>
                <select
                  className="form-control form-control-lg"
                  id="internet"
                  value={updateRoom.internet}
                  onChange={(e) => setInternet(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="breakfast">Breakfast</label>
                <select
                  className="form-control form-control-lg"
                  id="breakfast"
                  value={updateRoom.breakfast}
                  onChange={(e) => setBreakfast(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="ac">AC</label>
                <select
                  className="form-control form-control-lg"
                  id="ac"
                  value={updateRoom.ac}
                  onChange={(e) => setAc(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
          </div>

          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="petAllowed">Pet Allowed</label>
                <select
                  className="form-control form-control-lg"
                  id="petAllowed"
                  value={updateRoom.petAllowed}
                  onChange={(e) => setPetAllowed(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="roomCleaning">Room Cleaning</label>
                <select
                  className="form-control form-control-lg"
                  id="roomCleaning"
                  value={updateRoom.roomCleaning}
                  onChange={(e) => setRoomCleaning(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="category">Category</label>
                <select
                  className="form-control form-control-lg"
                  id="category"
                  value={updateRoom.category}
                  onChange={(e) => setCategory(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select category</option>
                  <option value="single">Single</option>
                  <option value="double">Double</option>
                  <option value="suite">Suite</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="pictures">Select Pictures (Multiple)</label>
                <input
                  type="file"
                  className="form-control form-control-lg"
                  id="pictures"
                  accept="image/*"
                  multiple="multiple"
                  onChange={handleImageChange}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div class="d-grid col-md-4 mt-4">
            <button class="btn btn-primary" type="submit">
              Update Room
            </button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default EditRoom;
