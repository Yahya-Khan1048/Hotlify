import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { message } from "antd";
import { Link } from "react-router-dom";
import axios from "axios";
import { Image } from "react-bootstrap";

const AllJobs = () => {
  const [job, setJob] = useState([]);
  const getJob = async () => {
    try {
      const res = await axios.get(`/api/v1/job/get-jobs`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setJob(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  //=========== Deleting room =============
  // ===== id is receiving from below delete button ========
  const handleDelete = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/job/delete-job/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        getJob();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("something went Wrong");
    }
  };

  useEffect(() => {
    getJob();
  }, []);
  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <div className="container">
          <div className="col-md-12 d-flex justify-content-between align-items-center">
            <div className="col-md-6">
              <h1>Employment Opportunities</h1>
            </div>
            <Link to="/applications">
              <button type="button" class="btn btn-primary btn-lg">
                View User Application
              </button>
            </Link>
          </div>
        </div>
        <div className="row p-3">
          {job && job.length > 0 ? (
            job.map((job, index) => (
              <div className="col-md-4 mb-4">
                <div className="card" style={{ width: "24rem" }}>
                  <Image
                    src="/images/Good.jpg"
                    alt="Job Image"
                    style={{ width: "382px", height: "270px" }}
                  />

                  <div
                    className="card-body"
                    style={{
                      background: "#00203fff",
                      border: "1px solid #adefd1ff",
                    }}
                  >
                    <div className="d-flex justify-content-between">
                      <h5 className="card-title"> {job.jobTitle}</h5>
                      <div>
                        <Link
                          onClick={() => handleDelete(job._id)}
                          style={{
                            border: "1px solid #ccc",
                            borderRadius: 5,
                            padding: 5,
                            marginRight: 10,
                          }}
                        >
                          <FontAwesomeIcon icon={faTrash} size="lg" />
                        </Link>
                        <Link
                          to={`/editjob/${job._id}`}
                          style={{
                            border: "1px solid #ccc",
                            borderRadius: 5,
                            padding: 5,
                          }}
                        >
                          <FontAwesomeIcon icon={faPenToSquare} size="lg" />{" "}
                        </Link>
                      </div>
                    </div>
                    <p className="card-text">
                      <strong>Location:</strong> {job.location}
                    </p>
                    <p className="card-text">
                      <strong>Salary:</strong> $:{job.salary}
                    </p>
                    <p className="card-text">
                      <strong>Job Type:</strong> {job.jobType}
                    </p>
                    <Link to={`/admin/details/${job._id}`}>
                      <div className="d-grid gap-2 col-12 mx-auto">
                        <button className="btn btn-primary" type="button">
                          Job Details
                        </button>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <h1>No Job Exists</h1>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default AllJobs;
