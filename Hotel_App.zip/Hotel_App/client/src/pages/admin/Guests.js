import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import axios from "axios";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
const Guests = () => {
  const [guest, setGuest] = useState([]);

  //========= Getting users ===========
  const Allguest = async () => {
    try {
      const res = await axios.post(
        `/api/v1/user/All-user`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        setGuest(res.data.data);
        message.success(res.data.message);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  //================== Delete Guests ===============
  const handleRemoveUser = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/user/delete-user/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        // Update the user list
        Allguest();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  //   ================ end =====================
  useEffect(() => {
    Allguest();
  }, []);

  return (
    <Layout>
      <div className="container row">
        <h1 className="text-center py-2">User Management Dashboard</h1>
        <div className="m-3 border shadow p-2 col-md-7 mx-auto">
          <table className="table table-hover">
            <thead>
              <tr className="bg-primary">
                <th scope="col">#</th>
                <th className="guest" scope="col">
                  Name
                </th>
                <th className="guest" scope="col">
                  Email
                </th>
                <th className="guest" scope="col">
                  Role
                </th>
                <th className="guest" scope="col">
                  joined On
                </th>
                <th className="guest" scope="col">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {guest.map((guest, index) => (
                <tr key={index}>
                  <th
                    scope="row"
                    style={{
                      background: "#00203fff",
                      color: "#adefd1ff",
                      border: "1px solid #adefd1ff",
                    }}
                  >
                    {index + 1}
                  </th>
                  <td className="guest">{guest.name}</td>
                  <td className="guest">{guest.email}</td>
                  <td className="guest">{guest.isAdmin ? "Admin" : "User"}</td>
                  <td className="guest">
                    {new Date(guest.createdAt).toLocaleDateString()}
                  </td>
                  <Link onClick={() => handleRemoveUser(guest._id)}>
                    <FontAwesomeIcon
                      style={{
                        marginTop: 10,
                        marginLeft: 10,
                        color: "#adefd1ff",
                      }}
                      icon={faTrash}
                      size="xl"
                    />
                  </Link>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};

export default Guests;
