import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import { Row, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from "axios";
import { message } from "antd";
import {
  faBed,
  faBuilding,
  faCalendarCheck,
} from "@fortawesome/free-solid-svg-icons";

const Report = () => {
  // ===== Room Reports ===//
  const [allRoom, setAllRoom] = useState([]);
  const [allHotel, setAllHotel] = useState([]);
  const [bookings, setAllBookings] = useState([]);
  const [guest, setGuest] = useState([]);
  const [userApplication, setUserApplication] = useState([]);
  //======== Fetching all Hotel data =========
  //======== Fetching all room data ==========
  const getHotel = async () => {
    try {
      const res = await axios.get(`/api/v1/hotel/get-hotel`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllHotel(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  //======== Fetching all room data ==========
  const getRoom = async () => {
    try {
      const res = await axios.get(`/api/v1/rooms/rooms`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllRoom(res.data.rooms);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  // ========== Fetching Booking data =========

  const getAllBookings = async () => {
    try {
      const res = await axios.get(`/api/v1/booking/all-userbooking`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllBookings(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  // ============= Fetching Guest Details =======
  const Allguest = async () => {
    try {
      const res = await axios.post(
        `/api/v1/user/All-user`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        setGuest(res.data.data);
        message.success(res.data.message);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  // =========== Fetching total Staff data =======
  const getAcceptedApplications = async () => {
    try {
      const res = await axios.get(`/api/v1/apply/get-accepted-applications`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setUserApplication(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  useEffect(() => {
    getHotel();
    getRoom();
    getAllBookings();
    Allguest();
    getAcceptedApplications();
  }, []);
  return (
    <Layout>
      <div>
        <h1 className="text-center mb-5">Hotel Performance Reviews</h1>
        <Row className="m-5">
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon icon={faBed} size="lg" className="me-3" />
                <h3>Room Utilization</h3>
              </div>
              <p>Total Rooms: {allRoom.length}</p>
              <p>
                Booked Rooms:{" "}
                {allRoom.filter((room) => room.status === "Booked").length}
              </p>
              <p>
                Vacant Rooms:{" "}
                {allRoom.filter((room) => room.status !== "Booked").length}
              </p>
            </div>
          </Col>
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon icon={faBuilding} size="lg" className="me-3" />
                <h3>Hotel Performance</h3>
              </div>
              <p>Total Hotels: {allHotel.length}</p>
              <p>
                Ready Hotels for Booking:{" "}
                {allHotel.filter((hotel) => hotel.status === "active").length}
              </p>
              <p>
                Under Maintenance:{" "}
                {allHotel.filter((hotel) => hotel.status !== "active").length}
              </p>
            </div>
          </Col>
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon
                  icon={faCalendarCheck}
                  size="lg"
                  className="me-3"
                />
                <h3>Booking Trends</h3>
              </div>
              <p>Total Booking: {bookings.length}</p>
              <p>
                Accepted Booking:{" "}
                {
                  bookings.filter((booking) => booking.status === "Accepted")
                    .length
                }
              </p>
              <p>
                Pending Booking:{" "}
                {
                  bookings.filter((booking) => booking.status !== "Accepted")
                    .length
                }
              </p>
            </div>
          </Col>
        </Row>
        <Row className="m-5">
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon icon={faBed} size="lg" className="me-3" />
                <h3>Member Details</h3>
              </div>
              <p>Total Guests: {guest.length}</p>
              <p>Admins: {guest.filter((guest) => guest.isAdmin).length}</p>
              <p>Users: {guest.filter((guest) => !guest.isAdmin).length}</p>
            </div>
          </Col>
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon icon={faBuilding} size="lg" className="me-3" />
                <h3>Staff Performance</h3>
              </div>
              <p>Total Applications: {userApplication.length}</p>
              <p>
                Full Time:{" "}
                {
                  userApplication.filter(
                    (application) => application.shift === "full-time"
                  ).length
                }
              </p>
              <p>
                Evening Shift:{" "}
                {
                  userApplication.filter(
                    (application) => application.shift !== "Full-time"
                  ).length
                }
              </p>
            </div>
          </Col>
          <Col md={4} className="mb-4">
            <div className="border p-4 shadow-sm">
              <div className="d-flex align-items-center mb-3">
                <FontAwesomeIcon
                  icon={faCalendarCheck}
                  size="lg"
                  className="me-3"
                />
                <h3>Revenue Analysis</h3>
              </div>
              <p>Maximize profitability, not just revenue</p>
              <p>Understand customer, market, and competition</p>
              <p>Revenue management is a daily mindset</p>
            </div>
          </Col>
        </Row>
      </div>
    </Layout>
  );
};

export default Report;
