import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import { useParams } from "react-router-dom";
import axios from "axios";
import { message } from "antd";
import { Link } from "react-router-dom";
const RoomDetails = () => {
  const [details, setDetails] = useState();
  const { id } = useParams();
  const getDetails = async () => {
    try {
      const res = await axios.get(`/api/v1/rooms/single-room/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      if (res.data.success) {
        setDetails(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  useEffect(() => {
    getDetails();
  }, [id]);
  return (
    <Layout>
      <div className="container mt-5 mr-5">
        {details && (
          <div className="row justify-content-center">
            <div className="col-md-8 pe-4" style={{ width: "65%" }}>
              <div className="row">
                {details.images.map((image, imgIndex) => (
                  <div
                    key={imgIndex}
                    className={`col-md-6 mb-4 ${
                      imgIndex % 2 === 0 ? "ps-0" : "pe-0"
                    }`}
                  >
                    <img
                      src={require(`../../images/${image}`)}
                      className="d-block w-100"
                      alt="..."
                      style={{
                        height: "250px",
                        objectFit: "cover",
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div
              className="col-md-4 ps-4"
              style={{ width: "35%", textAlign: "left" }}
            >
              <div className="room-details">
                <h1 className="mb-4">Room Details</h1>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Room Name:</strong>
                  </div>
                  <div className="col-md-6">{details.name}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6 ">
                    <strong>Price Per Night:</strong>
                  </div>
                  <div className="col-md-6">{details.pricePerNight}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Description:</strong>
                  </div>
                  <div className="col-md-6">{details.description}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Address:</strong>
                  </div>
                  <div className="col-md-6">{details.address}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Guest Capacity:</strong>
                  </div>
                  <div className="col-md-6">{details.guestCapacity}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Number of Beds:</strong>
                  </div>
                  <div className="col-md-6">{details.numOfBeds}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Internet:</strong>
                  </div>
                  <div className="col-md-6">
                    {details.internet ? "Yes" : "No"}
                  </div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Breakfast:</strong>
                  </div>
                  <div className="col-md-6">
                    {details.breakfast ? "Yes" : "No"}
                  </div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>AC:</strong>
                  </div>
                  <div className="col-md-6">{details.ac ? "Yes" : "No"}</div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Pet Allowed:</strong>
                  </div>
                  <div className="col-md-6">
                    {details.petAllowed ? "Yes" : "No"}
                  </div>
                </div>
                <div className="row mb-2">
                  <div className="col-md-6">
                    <strong>Room Cleaning:</strong>
                  </div>
                  <div className="col-md-6">
                    {details.roomCleaning ? "Yes" : "No"}
                  </div>
                </div>

                <Link to={`/booking/${details._id}`}>
                  <div className="d-grid gap-2 col-12 mt-5 mx-auto">
                    <button className="btn btn-primary" type="button">
                      Book Now
                    </button>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default RoomDetails;
