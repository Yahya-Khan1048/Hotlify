import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
const Staff = () => {
  const [userApplication, setUserApplication] = useState([]);
  const getAcceptedApplications = async () => {
    try {
      const res = await axios.get(`/api/v1/apply/get-accepted-applications`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setUserApplication(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  const handleRemoveUser = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/apply/delete-application/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        getAcceptedApplications(); // Update the application list
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getAcceptedApplications();
  }, []);
  return (
    <Layout>
      <div className="container row">
        <h1 className="text-center py-2">Staff Management Dashboard</h1>
        <div className="m-3 border shadow p-2 col-md-11 mx-auto">
          <table className="table table-hover">
            <thead>
              <tr className="bg-primary">
                <th className="guest" scope="col">
                  #
                </th>
                <th className="guest" scope="col">
                  Name
                </th>
                <th className="guest" scope="col">
                  Job Title
                </th>
                <th className="guest" scope="col">
                  Email
                </th>
                <th className="guest" scope="col">
                  Address
                </th>
                <th className="guest" scope="col">
                  Age
                </th>
                <th className="guest" scope="col">
                  Phone No
                </th>
                <th className="guest" scope="col">
                  Education
                </th>
                <th className="guest" scope="col">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {userApplication.map((guest, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td className="guest">{guest.name}</td>
                  <td className="guest">{guest.jobTitle}</td>
                  <td className="guest">{guest.email}</td>
                  <td className="guest">{guest.address}</td>
                  <td className="guest">{guest.age}</td>
                  <td className="guest">{guest.phone}</td>
                  <td className="guest">{guest.education}</td>

                  <Link onClick={() => handleRemoveUser(guest._id)}>
                    <FontAwesomeIcon
                      style={{
                        marginTop: 10,
                        marginLeft: 10,
                        color: "#adefd1ff",
                      }}
                      icon={faTrash}
                      size="xl"
                    />
                  </Link>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};

export default Staff;
