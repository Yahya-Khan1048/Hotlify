import React, { useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const HotelForm = () => {
  const [name, setName] = useState();
  const [address, setAddress] = useState();
  const [phone, setPhone] = useState();
  const [email, setEmail] = useState();
  const [stars, setStars] = useState();
  const [checkinTime, setCheckinTime] = useState();
  const [checkoutTime, setCheckoutTime] = useState();
  const [description, setDescription] = useState();
  const [status, setStatus] = useState("active");
  const [images, setImages] = useState();
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !name ||
      !address ||
      !phone ||
      !email ||
      !stars ||
      !checkinTime ||
      !checkoutTime ||
      !description ||
      !status ||
      !images
    ) {
      message.error("Please fill in all fields");
      return;
    }
    if (!images || images.length === 0) {
      message.error("Please select at least one image");
      return;
    }
    try {
      const hotelData = new FormData();
      hotelData.append("name", name);
      hotelData.append("address", address);
      hotelData.append("phone", phone);
      hotelData.append("email", email);
      hotelData.append("stars", stars);
      hotelData.append("checkinTime", checkinTime);
      hotelData.append("checkoutTime", checkoutTime);
      hotelData.append("description", description);
      hotelData.append("status", status);
      images.forEach((image) => {
        hotelData.append("images", image);
      });
      const userId = localStorage.getItem("userId");
      if (userId) {
        hotelData.append("userId", userId);
      }
      const token = localStorage.getItem("token");
      if (!token) {
        message.error("Token not found");
        return;
      }
      const res = await axios.post("/api/v1/hotel/create-hotel", hotelData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/hotels");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  const handleImageChange = (e) => {
    const selectedImages = e.target.files;
    const imagesArray = [];
    for (let i = 0; i < selectedImages.length; i++) {
      imagesArray.push(selectedImages[i]);
    }
    setImages(imagesArray);
  };

  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <h1 className="mb-3 pb-4">Hotel Registration Form</h1>
        <form onSubmit={handleSubmit}>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Name">Hotel Name</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Name"
                  placeholder="Enter hotel name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Address">Address</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Address"
                  placeholder="Enter address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Phone">Phone</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="Phone"
                  placeholder="Enter phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Email">Email</label>
                <input
                  type="email"
                  className="form-control form-control-lg"
                  id="Email"
                  placeholder="Enter email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Stars">Stars</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="Stars"
                  placeholder="Enter stars"
                  value={stars}
                  onChange={(e) => setStars(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="CheckinTime">Checkin Time</label>
                <input
                  type="datetime-local"
                  className="form-control form-control-lg"
                  id="CheckinTime"
                  placeholder="Enter checkin time"
                  value={checkinTime}
                  onChange={(e) => setCheckinTime(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="CheckoutTime">Checkout Time</label>
                <input
                  type="datetime-local"
                  className="form-control form-control-lg"
                  id="CheckoutTime"
                  placeholder="Enter checkout time"
                  value={checkoutTime}
                  onChange={(e) => setCheckoutTime(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Description">Description</label>
                <textarea
                  className="form-control form-control-lg"
                  id="Description"
                  placeholder="Enter description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="Status">Status</label>
                <select
                  className="form-control form-control-lg"
                  id="Status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="under maintenance">Under Maintenance</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="pictures">Select Pictures (Multiple)</label>
                <input
                  type="file"
                  className="form-control form-control-lg"
                  id="pictures"
                  accept="image/*"
                  multiple="multiple"
                  onChange={handleImageChange}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="d-grid col-md-4 mt-4">
            <button className="btn btn-primary" type="submit">
              Submit
            </button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default HotelForm;
