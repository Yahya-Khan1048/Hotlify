import React, { useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
const JobForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [jobTitle, setJobTitle] = useState();
  const [jobDescription, setJobDescription] = useState();
  const [hotelName, setHotelName] = useState();
  const [location, setLocation] = useState();
  const [jobType, setJobType] = useState();
  const [shift, setShift] = useState();
  const [jobCategory, setJobCategory] = useState();
  const [requiredSkills, setRequiredSkills] = useState();
  const [experience, setExperience] = useState();
  const [education, setEducation] = useState();
  const [salary, setSalary] = useState();
  const [jobStatus, setJobStatus] = useState();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !jobTitle ||
      !jobDescription ||
      !hotelName ||
      !location ||
      !jobType ||
      !shift ||
      !jobCategory ||
      !requiredSkills ||
      !experience ||
      !education ||
      !salary ||
      !jobStatus
    ) {
      message.error("Please fill in all fields");
      return;
    }
    try {
      const res = await axios.post(
        "/api/v1/job/create-job",
        {
          jobTitle,
          jobDescription,
          hotelName,
          hotel: id, // Save the id from useParams in the hotel attribute
          location,
          jobType,
          shift,
          jobCategory,
          requiredSkills,
          experience,
          education,
          salary,
          jobStatus,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/hotels");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <h1 style={{ marginTop: "20px", marginBottom: "20px" }}>
          Hotel Employment Opportunity
          <br /> Form for Job
        </h1>
        <form onSubmit={handleSubmit}>
          {/* row 1 */}
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="jobTitle">Job Title</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="jobTitle"
                  placeholder="Enter job title"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="jobDescription">Job Description</label>
                <textarea
                  className="form-control form-control-lg"
                  id="jobDescription"
                  placeholder="Enter job description"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="hotelName">Hotel Name</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="hotelName"
                  placeholder="Enter hotel name"
                  value={hotelName}
                  onChange={(e) => setHotelName(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          {/* end */}
          {/* row 2 */}
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="location">Location</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="location"
                  placeholder="Enter location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="jobType">Job Type</label>
                <select
                  className="form-control form-control-lg"
                  id="jobType"
                  value={jobType}
                  onChange={(e) => setJobType(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="full-time">Full-time</option>
                  <option value="part-time">Part-time</option>
                  <option value="seasonal">Seasonal</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="shift">Shift</label>
                <select
                  className="form-control form-control-lg"
                  id="shift"
                  value={shift}
                  onChange={(e) => setShift(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="morning">Morning</option>
                  <option value="afternoon">Afternoon</option>
                  <option value="evening">Evening</option>
                </select>
              </div>
            </div>
          </div>
          {/* end */}
          {/* row 3 */}
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="jobCategory">Job Category</label>
                <select
                  className="form-control form-control-lg"
                  id="jobCategory"
                  value={jobCategory}
                  onChange={(e) => setJobCategory(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="front-desk">Front Desk</option>
                  <option value="housekeeping">Housekeeping</option>
                  <option value="food-and-beverage">Food and Beverage</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="requiredSkills">Required Skills</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="requiredSkills"
                  placeholder="Enter required skills"
                  value={requiredSkills}
                  onChange={(e) => setRequiredSkills(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="experience">Experience</label>
                <select
                  className="form-control form-control-lg"
                  id="experience"
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="entry-level">Entry-level</option>
                  <option value="mid-level">Mid-level</option>
                  <option value="senior-level">Senior-level</option>
                </select>
              </div>
            </div>
          </div>
          {/* end */}
          {/* row 4 */}
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="education">Education</label>
                <select
                  className="form-control form-control-lg"
                  id="education"
                  value={education}
                  onChange={(e) => setEducation(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="high-school-diploma">
                    High School Diploma
                  </option>
                  <option value="degree">Degree</option>
                  <option value="certification">Certification</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="salary">Salary</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="salary"
                  placeholder="Enter salary"
                  value={salary}
                  onChange={(e) => setSalary(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="jobStatus">Job Status</label>
                <select
                  className="form-control form-control-lg"
                  id="jobStatus"
                  value={jobStatus}
                  onChange={(e) => setJobStatus(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="open">Open</option>
                  <option value="closed">Closed</option>
                  <option value="pending">Pending</option>
                </select>
              </div>
            </div>
          </div>
          {/* end */}
          <div className="d-grid col-md-12 mx-auto mt-5">
            <button className="btn btn-primary form-control-lg" type="submit">
              Create Job
            </button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default JobForm;
