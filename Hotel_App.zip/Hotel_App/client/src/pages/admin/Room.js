// ======================= Creating Room Page ===================
// ================== //
import React, { useState } from "react";
import Layout from "../../components/Layout/Layout";
import { message } from "antd";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
const Room = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  // State variables for each input field
  const [name, setName] = useState("");
  const [pricePerNight, setPricePerNight] = useState("");
  const [description, setDescription] = useState("");
  const [address, setAddress] = useState("");
  const [guestCapacity, setGuestCapacity] = useState("");
  const [numOfBeds, setNumOfBeds] = useState("");
  const [internet, setInternet] = useState("");
  const [breakfast, setBreakfast] = useState("");
  const [ac, setAc] = useState("");
  const [petAllowed, setPetAllowed] = useState("");
  const [roomCleaning, setRoomCleaning] = useState("");
  const [category, setCategory] = useState("");
  const [images, setImages] = useState();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !name ||
      !pricePerNight ||
      !description ||
      !address ||
      !guestCapacity ||
      !numOfBeds ||
      !internet ||
      !breakfast ||
      !ac ||
      !petAllowed ||
      !roomCleaning ||
      !category ||
      !images
    ) {
      message.error("Please fill in all fields");
      return;
    }
    try {
      const applyData = new FormData();
      applyData.append("name", name);
      applyData.append("pricePerNight", pricePerNight);
      applyData.append("description", description);
      applyData.append("address", address);
      applyData.append("guestCapacity", guestCapacity);
      applyData.append("numOfBeds", numOfBeds);
      applyData.append("internet", internet);
      applyData.append("breakfast", breakfast);
      applyData.append("ac", ac);
      applyData.append("petAllowed", petAllowed);
      applyData.append("roomCleaning", roomCleaning);
      applyData.append("category", category);
      applyData.append("images", images[0]);
      applyData.append("images", images[1]);
      applyData.append("images", images[2]);
      applyData.append("images", images[3]);
      applyData.append("hotelId", id); // Add the hotelId to the form data
      const userId = localStorage.getItem("userId");
      if (userId) {
        applyData.append("userId", userId);
      }
      const res = await axios.post("/api/v1/rooms/create-rooms", applyData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/hotels");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  const handleImageChange = (e) => {
    setImages(e.target.files);
  };

  return (
    <Layout>
      <div className="container-fluid" style={{ padding: "1% 10%" }}>
        <form onSubmit={handleSubmit}>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="name">Room Name</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="name"
                  placeholder="Enter room name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="pricePerNight">Price Per Night</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="pricePerNight"
                  placeholder="Enter price per night"
                  value={pricePerNight}
                  onChange={(e) => setPricePerNight(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="description">Description</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="description"
                  placeholder="Enter room description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="address">Address</label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  id="address"
                  placeholder="Enter address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="guestCapacity">Guest Capacity</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="guestCapacity"
                  placeholder="Enter guest capacity"
                  value={guestCapacity}
                  onChange={(e) => setGuestCapacity(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="numOfBeds">Number of Beds</label>
                <input
                  type="number"
                  className="form-control form-control-lg"
                  id="numOfBeds"
                  placeholder="Enter number of beds"
                  value={numOfBeds}
                  onChange={(e) => setNumOfBeds(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="internet">Internet</label>
                <select
                  className="form-control form-control-lg"
                  id="internet"
                  value={internet}
                  onChange={(e) => setInternet(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="breakfast">Breakfast</label>
                <select
                  className="form-control form-control-lg"
                  id="breakfast"
                  value={breakfast}
                  onChange={(e) => setBreakfast(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="ac">AC</label>
                <select
                  className="form-control form-control-lg"
                  id="ac"
                  value={ac}
                  onChange={(e) => setAc(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
          </div>

          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="petAllowed">Pet Allowed</label>
                <select
                  className="form-control form-control-lg"
                  id="petAllowed"
                  value={petAllowed}
                  onChange={(e) => setPetAllowed(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="roomCleaning">Room Cleaning</label>
                <select
                  className="form-control form-control-lg"
                  id="roomCleaning"
                  value={roomCleaning}
                  onChange={(e) => setRoomCleaning(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="category">Category</label>
                <select
                  className="form-control form-control-lg"
                  id="category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                >
                  <option value="">Select category</option>
                  <option value="single">Single</option>
                  <option value="double">Double</option>
                  <option value="suite">Suite</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row" style={{ marginBottom: "20px" }}>
            <div className="col-md-4">
              <div className="form-group">
                <label htmlFor="pictures">Select Pictures (Multiple)</label>
                <input
                  type="file"
                  className="form-control form-control-lg"
                  id="pictures"
                  accept="image/*"
                  multiple="multiple"
                  onChange={handleImageChange}
                  style={{
                    background: "#00203fff",
                    color: "#adefd1ff",
                    border: "1px solid #adefd1ff",
                  }}
                />
              </div>
            </div>
          </div>
          <div class="d-grid col-md-4 mt-4">
            <button class="btn btn-primary" type="submit">
              Submit
            </button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default Room;
