import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout/Layout";
import axios from "axios";
import { message } from "antd";

const UsersBooking = () => {
  const [bookings, setAllBookings] = useState([]);

  const getAllBookings = async () => {
    try {
      const res = await axios.get(`/api/v1/booking/all-userbooking`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllBookings(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getAllBookings();
  }, []);

  //================== Accept Booking ==================
  const handleAcceptBooking = async (id) => {
    try {
      const res = await axios.post(
        `/api/v1/booking/accept-booking/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        getAllBookings();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  //================= Reject Booking ==================
  const handleRejectBooking = async (id) => {
    try {
      const res = await axios.post(
        `/api/v1/booking/reject-booking/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        getAllBookings();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  // ================ End ============================

  return (
    <Layout>
      <>
        <h1 className="text-center p-3">Room Booking Overview</h1>
        <div className="row p-2 m-2">
          {bookings.map((booking) => (
            <div
              key={booking._id}
              className="col-md-5 row mx-auto m-3 border shadow p-2"
            >
              <div className="col-md-6">
                <h3>Booking Details</h3>
                <hr />
                <h4>Person: {booking.name}</h4>
                <p>
                  {" "}
                  <b> Check-in:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  {new Date(booking.checkInDate).toLocaleDateString()}{" "}
                </p>

                <p>
                  <b> Check-out:</b>&nbsp;&nbsp;&nbsp;&nbsp;
                  {new Date(booking.checkOutDate).toLocaleDateString()}
                </p>
                <p>
                  {" "}
                  <b>Number of guests:</b>&nbsp;&nbsp; {booking.numberOfGuests}
                </p>
                <p>
                  {" "}
                  <b>Address:</b>&nbsp;&nbsp;&nbsp;&nbsp; {booking.address}
                </p>
                <p>
                  <b> Booked on:</b>&nbsp;&nbsp;&nbsp;
                  {new Date(booking.createdAt).toLocaleDateString()}
                </p>
              </div>

              <div className=" row gap-2 col-6 mx-auto p-5 mt-5">
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => handleAcceptBooking(booking._id)}
                >
                  Accept Booking
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleRejectBooking(booking._id)}
                >
                  Reject Booking
                </button>
              </div>
            </div>
          ))}
        </div>
      </>
    </Layout>
  );
};

export default UsersBooking;
