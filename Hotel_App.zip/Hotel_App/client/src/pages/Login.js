import React, { useState } from "react";
import "./Register.css";
import { NavLink } from "react-router-dom";
import { message } from "antd";
import axios from "axios";
import { useDispatch } from "react-redux";
import { showLoading, hideLoading } from "../redux/features/alertSlice";
import { useNavigate } from "react-router-dom";
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  //form handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      dispatch(showLoading());
      const res = await axios.post("/api/v1/user/login", { email, password });
      dispatch(hideLoading());
      if (res.data.success) {
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("userId", res.data.user._id);
        message.success("Login Successfully");
        navigate("/");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      dispatch(hideLoading());
      console.log(error);
      message.error("something went wrong");
    }
  };
  return (
    <>
      <div className="register-container">
        <div className="register-form">
          <div className="image-section">
            <img src="/images/login.jpg" alt="Sign up" />
            <NavLink className="login-link" to="/register">
              You haven't account! Sign Up
            </NavLink>
          </div>
          <div className="form-section mt-6">
            <h1>Login Form</h1>
            <form onSubmit={handleSubmit}>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                name="email"
                required
              />
              <input
                type="password"
                value={password}
                placeholder="Password"
                name="password"
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <div className="form-group">
                <input type="checkbox" name="terms" id="terms" required />
                <label htmlFor="terms">
                  I agree to all statements in{" "}
                  <NavLink to={"/login"}>Terms of Service</NavLink>
                </label>
              </div>
              <button type="submit">Login</button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
