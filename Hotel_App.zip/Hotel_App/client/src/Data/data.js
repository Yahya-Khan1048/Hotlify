export const userMenu = [
  {
    name: "Home",
    path: "/",
    icon: "fa-solid fa-house",
  },
  {
    name: "Hotel",
    path: "/user/hotels",
    icon: "fa-solid fa-list",
  },
  {
    name: "Careers",
    path: "/user/careers",
    icon: "fa-solid fa-briefcase",
  },
  {
    name: "Profile",
    path: "/user/profile",
    icon: "fa-solid fa-briefcase",
  },
  {
    name: "chat",
    path: "/user/chat",
    icon: "fa-solid fa-briefcase",
  },
];

// ======= admin menu =====
export const adminMenu = [
  {
    name: "Hotels",
    path: "/admin/hotels",
    icon: "fa-solid fa-building",
  },
  {
    name: "Rooms",
    path: "/admin/rooms",
    icon: "fa-solid fa-bed",
  },
  {
    name: "Guests",
    path: "/admin/guests",
    icon: "fa-solid fa-users",
  },
  {
    name: "Bookings",
    path: "/admin/bookings",
    icon: "fa-solid fa-calendar-check",
  },
  {
    name: "Staff",
    path: "/admin/staff",
    icon: "fa-solid fa-user-tie",
  },
  {
    name: "Reports",
    path: "/admin/reports",
    icon: "fa-solid fa-chart-bar",
  },
  {
    name: "Jobs",
    path: "/admin/jobs",
    icon: "fa-solid fa-briefcase",
  },
];
