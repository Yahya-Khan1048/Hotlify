import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage";
import Register from "./pages/Register";
import Login from "./pages/Login";
import ProtectedRoute from "./components/ProtectedRoute";
import PublicRoute from "./components/PublicRoute";
import AllRoom from "./pages/admin/AllRoom";
import EditRoom from "./pages/admin/EditRoom";
import Room from "./pages/admin/Room";
import RoomDetails from "./pages/admin/RoomDetails";
import Booking from "./pages/user/Booking";
import AllHotel from "./pages/admin/AllHotel";
import AdminRooms from "./pages/admin/adminRooms";
import UserHotel from "./pages/user/UserHotel";
import HotelForm from "./pages/admin/HotelForm";
import Rooms from "./pages/user/Rooms";
import MyBooking from "./pages/user/MyBooking";
import UsersBooking from "./pages/admin/UsersBooking";
import Guests from "./pages/admin/Guests";
import JobForm from "./pages/admin/JobForm";
import AllJobs from "./pages/admin/AllJobs";
import EditJob from "./pages/admin/EditJob";
import AvaliableJobs from "./pages/user/AvaliableJobs";
import JobDetails from "./pages/user/JobDetails";
import JobApply from "./pages/user/JobApply";
import Profile from "./pages/user/Profile";
import Application from "./pages/user/Application";
import UserApplication from "./pages/admin/UserApplication";
import Staff from "./pages/admin/Staff";
import Report from "./pages/admin/Report";
import Chat from "./pages/user/Chat";

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <HomePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-room/:id"
            element={
              <ProtectedRoute>
                <Room />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-job/:id"
            element={
              <ProtectedRoute>
                <JobForm />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit/:id"
            element={
              <ProtectedRoute>
                <EditRoom />
              </ProtectedRoute>
            }
          />
          <Route
            path="/details/:id"
            element={
              <ProtectedRoute>
                <RoomDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/room/:id"
            element={
              <ProtectedRoute>
                <AllRoom />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/hotels"
            element={
              <ProtectedRoute>
                <AllHotel />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/create-hotel"
            element={
              <ProtectedRoute>
                <HotelForm />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/rooms"
            element={
              <ProtectedRoute>
                <AdminRooms />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/guests"
            element={
              <ProtectedRoute>
                <Guests />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/bookings"
            element={
              <ProtectedRoute>
                <UsersBooking />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/staff"
            element={
              <ProtectedRoute>
                <Staff />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/reports"
            element={
              <ProtectedRoute>
                <Report />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/jobs"
            element={
              <ProtectedRoute>
                <AllJobs />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/details/:id"
            element={
              <ProtectedRoute>
                <JobDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/applications"
            element={
              <ProtectedRoute>
                <UserApplication />
              </ProtectedRoute>
            }
          />
          <Route
            path="/editjob/:id"
            element={
              <ProtectedRoute>
                <EditJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/hotels"
            element={
              <ProtectedRoute>
                <UserHotel />
              </ProtectedRoute>
            }
          />
          <Route
            path="/rooms/:id"
            element={
              <ProtectedRoute>
                <Rooms />
              </ProtectedRoute>
            }
          />
          <Route
            path="/booking/:id"
            element={
              <ProtectedRoute>
                <Booking />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/mybooking"
            element={
              <ProtectedRoute>
                <MyBooking />
              </ProtectedRoute>
            }
          />

          <Route
            path="/user/careers"
            element={
              <ProtectedRoute>
                <AvaliableJobs />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/chat"
            element={
              <ProtectedRoute>
                <Chat />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/user-application"
            element={
              <ProtectedRoute>
                <Application />
              </ProtectedRoute>
            }
          />
          <Route
            path="/JobDetails/:id"
            element={
              <ProtectedRoute>
                <JobDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/JobApply/:id/:title"
            element={
              <ProtectedRoute>
                <JobApply />
              </ProtectedRoute>
            }
          />
          <Route
            path="/register"
            element={
              <PublicRoute>
                <Register />
              </PublicRoute>
            }
          />
          <Route
            path="/login"
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;
