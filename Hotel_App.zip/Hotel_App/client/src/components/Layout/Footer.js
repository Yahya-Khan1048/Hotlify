import React from "react";
import { NavLink } from "react-router-dom";
import "./Footer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";

const Footer = () => {
  return (
    <div className="footer">
      <div className="sb_footer section_padding">
        <div className="sb_footer_link">
          <div className="sb_footer_link_div">
            <h2> About Us</h2>
            <NavLink to="/">
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Our Story
            </NavLink>

            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp; Mission & Values
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp; Team Members
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp;Careers
            </NavLink>
          </div>
          <div className="sb_footer_link_div">
            <h2> Services</h2>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp;Room Amenities
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp;Dining Options
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Fitness Center
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp; &nbsp; Concierge
            </NavLink>
          </div>
          <div className="sb_footer_link_div">
            <h2>Explore </h2>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Destination Guide
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Promotions
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Packages & Offers
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Travel Tips
            </NavLink>
          </div>
          <div className="sb_footer_link_div">
            <h2>Reports</h2>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Rooms
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Staff
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Jobs
            </NavLink>
            <NavLink to="/">
              {" "}
              &nbsp;&nbsp;
              <FontAwesomeIcon icon={faChevronRight} />
              &nbsp;&nbsp; Guest
            </NavLink>
          </div>
        </div>
        <hr />
        <div className="sb_footer_below">
          <div className="sb_footer_copyright">
            <p> @{new Date().getFullYear()} Hotel. All right Reserved</p>
          </div>
          <div className="sb_footer_below_link">
            <NavLink to="/">
              <p>Term & Conditions</p>
              <p>Privacy </p>
              <p>Security</p>
              <p>Cookies Declearation</p>
            </NavLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
