import React from "react";
import { NavLink } from "react-router-dom";
const userMenu = () => {
  return (
    <div className="text-center">
      <div className="list-group">
        <h2 className="mb-4">User Pannel</h2>
        <NavLink
          to="/user/profile"
          className="list-group-item list-group-item-action"
          style={{
            background: " #00203fff",
            color: "#adefd1ff",
            border: "1px solid #adefd1ff",
          }}
        >
          Manage Profile
        </NavLink>
        <NavLink
          to="/user/user-application"
          className="list-group-item list-group-item-action"
          style={{
            background: " #00203fff",
            color: "#adefd1ff",
            border: "1px solid #adefd1ff",
          }}
        >
          My Applications
        </NavLink>
        <NavLink
          to="/user/mybooking"
          className="list-group-item list-group-item-action"
          style={{
            background: " #00203fff",
            color: "#adefd1ff",
            border: "1px solid #adefd1ff",
          }}
        >
          My Booking
        </NavLink>
      </div>
    </div>
  );
};

export default userMenu;
