import React from "react";
import { NavLink } from "react-router-dom";
import "./Header.css";
import { message } from "antd";
import { useNavigate } from "react-router-dom";
import { userMenu, adminMenu } from "../../Data/data";
import { useSelector } from "react-redux";
const Header = () => {
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.user);
  // console.log(user && user.name);
  //======= logout function ===
  const handleLogout = () => {
    localStorage.clear();
    message.success("Logout Successfully");
    navigate("/login");
  };
  //============== Menu menu ===========
  const sidebarMenu = user?.admin ? adminMenu : userMenu;
  return (
    <header>
      <div className="container">
        <div
          className="logo-brand"
          style={{ marginLeft: "20px", paddingLeft: "20px" }}
        >
          <NavLink
            to="/"
            style={{
              marginLeft: "10px",
              paddingLeft: "10px",
              fontSize: "34px",
              fontWeight: "bold",
            }}
          >
            Hotelify
          </NavLink>
        </div>

        <nav>
          <ul>
            {sidebarMenu.map((menu) => (
              <li>
                <i className={menu.icon}></i>
                <NavLink to={menu.path}>{menu.name}</NavLink>
              </li>
            ))}
            {user && user.name ? (
              <li>
                <NavLink onClick={handleLogout} to="/login">
                  Logout
                </NavLink>
              </li>
            ) : (
              <>
                <li>
                  <NavLink to="/register">Register</NavLink>
                </li>
                <li>
                  <NavLink to="/login">Login</NavLink>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
