import React, { useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { showLoading } from "../redux/features/alertSlice"; // Import showLoading from the alertSlice redux feature
import axios from "axios"; // Import axios for making API requests
import { setUser } from "../redux/features/userSlice"; // Import setUser from the userSlice redux feature

export const hideLoading = () => (dispatch) => {
  setTimeout(() => {
    dispatch({ type: "alerts/hideLoading" }); // Dispatch the hideLoading action after a 1-second delay
  }, 1000);
};

export default function ProtectedRoute({ children }) {
  const dispatch = useDispatch();
  const { user, isLoading } = useSelector((state) => state.user);
  // eslint-disable-next-line
  const getUser = async () => {
    try {
      dispatch(showLoading()); // Show the loading indicator
      const res = await axios.post(
        // Make a POST request to the API
        "/api/v1/user/getUserData",
        { token: localStorage.getItem("token") }, // Pass the token in the request body
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Set the Authorization header with the token
          },
        }
      );
      dispatch(hideLoading()); // Hide the loading indicator
      if (res.data.success) {
        dispatch(setUser(res.data.data)); // Set the user data in the redux store
      } else {
        <Navigate to="/login" />; // Navigate to the login page if the API request fails
        localStorage.clear();
      }
    } catch (error) {
      dispatch(hideLoading()); // Hide the loading indicator on error
      localStorage.clear();
      console.log(error); // Log the error
    }
  };

  // Use the useEffect hook to call the getUser function when the component mounts
  useEffect(() => {
    if (!user && !isLoading) {
      getUser();
    }
  }, [user, isLoading, getUser]);

  if (localStorage.getItem("token")) {
    return children;
  } else {
    return <Navigate to="/login" />;
  }
}
