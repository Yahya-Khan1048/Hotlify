import mongoose from "mongoose";
const jobSchema = new mongoose.Schema({
  jobTitle: {
    type: String,
    required: true,
  },
  jobDescription: {
    type: String,
    required: true,
  },
  hotelName: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  jobType: {
    type: String,
    enum: ["full-time", "part-time", "seasonal"],
    required: true,
  },
  shift: {
    type: String,
    enum: ["morning", "afternoon", "evening"],
    required: true,
  },
  jobCategory: {
    type: String,
    enum: ["front-desk", "housekeeping", "food-and-beverage"],
    required: true,
  },
  requiredSkills: {
    type: String,
    required: true,
  },
  experience: {
    type: String,
    enum: ["entry-level", "mid-level", "senior-level"],
    required: true,
  },
  education: {
    type: String,
    enum: ["high-school-diploma", "degree", "certification"],
    required: true,
  },
  salary: {
    type: Number,
    required: true,
  },
  jobStatus: {
    type: String,
    enum: ["open", "closed", "pending"],
    required: true,
  },
  hotel: {
    type: mongoose.ObjectId, //getting user id
    ref: "Hotel",
    required: true,
  },
});

export default mongoose.model("Job", jobSchema);
