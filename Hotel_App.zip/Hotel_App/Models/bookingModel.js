import mongoose from "mongoose";
const bookingSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Enter Your name"],
    },
    email: {
      type: String,
      required: [true, "Enter Your email"],
    },
    phoneNumber: {
      type: Number,
      required: [true, "Enter Your number"],
    },
    checkInDate: {
      type: Date,
      required: [true, "Enter check In Date"],
    },
    checkOutDate: {
      type: Date,
      required: [true, "Enter check out date"],
    },
    numberOfGuests: {
      type: Number,
      required: [true, "Enter number of guest"],
    },
    address: {
      type: String,
      required: [true, "Enter Your address"],
    },
    status: {
      type: String,
      default: "pending",
    },
    user: {
      type: mongoose.ObjectId, //getting user id
      ref: "User",
      required: true,
    },
    room: {
      type: mongoose.ObjectId, //getting user id
      ref: "room",
      required: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("booking", bookingSchema);
