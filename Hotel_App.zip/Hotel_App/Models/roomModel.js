import mongoose from "mongoose";

const roomSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Room name is required"],
      maxlength: [100, "Room name must be 100 character long"],
    },
    pricePerNight: {
      type: Number,
      required: [true, "Room price is required"],
      default: 0.0,
    },
    description: {
      type: String,
      required: [true, "Room description is required"],
    },
    address: {
      type: String,
      required: [true, "address is required"],
    },
    guestCapacity: {
      type: Number,
      required: [true, "Room guest number is required"],
    },
    numOfBeds: {
      type: Number,
      required: [true, "Room bed number is required"],
    },
    internet: {
      type: Boolean,
      default: false,
    },
    breakfast: {
      type: Boolean,
      default: false,
    },
    ac: {
      type: Boolean,
      default: false,
    },
    petAllowed: {
      type: Boolean,
      default: false,
    },
    roomCleaning: {
      type: Boolean,
      default: false,
    },
    status: {
      type: String,
      default: "pending",
    },
    images: [{ type: String }],
    category: {
      type: String,
      required: [true, "Room category is required"],
    },
    // to know who create it
    user: {
      type: mongoose.ObjectId, //getting user id
      ref: "User",
      required: true,
    },
    hotel: {
      type: mongoose.ObjectId, //getting user id
      ref: "Hotel",
      required: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("room", roomSchema);
