import mongoose from "mongoose";

const staffSchema = new mongoose.Schema(
  {
    HotelID: {
      type: Number,
      ref: "Hotel",
    },
    FirstName: {
      type: String,
      required: true,
    },
    LastName: {
      type: String,
      required: true,
    },
    Position: {
      type: String,
      required: true,
    },
    Salary: {
      type: Number,
      required: true,
    },
    DateOfBirth: {
      type: Date,
      required: true,
    },
    Phone: {
      type: String,
      required: true,
    },
    Email: {
      type: String,
      required: true,
      unique: true,
    },
    HireDate: {
      type: Date,
      required: true,
    },
    Approved: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Staff", staffSchema);
