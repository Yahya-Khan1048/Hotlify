import mongoose from "mongoose";

const applicationSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
    },
    email: {
      type: String,
      required: [true, "Email is required"],
    },
    phone: {
      type: String,
      required: [true, "Phone number is required"],
    },
    address: {
      type: String,
      required: [true, "Address is required"],
    },
    age: {
      type: Number,
      required: [true, "Age is required"],
    },
    availability: {
      type: String,
      required: [true, "Avaliability is required"],
    },
    coverLetter: {
      type: String,
      required: [true, "Cover Letter is required"],
    },
    education: {
      type: String,
      required: [true, "Education is required"],
    },
    jobId: {
      type: String,
      required: true,
    },
    jobTitle: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      default: "pending",
    },
  },
  { timestamps: true }
);

export default mongoose.model("UserApplication", applicationSchema);
