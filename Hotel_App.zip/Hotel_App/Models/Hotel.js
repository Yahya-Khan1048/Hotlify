import mongoose from "mongoose";
const hotelSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, "Hotel name is required"] },
    address: { type: String, required: [true, "Address is required"] },
    phone: { type: String, required: [true, "Phone is required"] },
    email: { type: String, required: [true, "Email is required"] },
    stars: { type: Number, required: [true, "Stars is required"] },
    checkinTime: { type: Date, required: [true, "CheckinTime is required"] },
    checkoutTime: { type: Date, required: [true, "CheckoutTime is required"] },
    description: { type: String, required: [true, "Description is required"] },
    user: {
      type: mongoose.Schema.ObjectId,
      ref: "Users",
      required: true,
    },
    status: {
      type: String,
      enum: ["active", "inactive", "under maintenance"],
      default: "active",
    },
    images: [{ type: String }],
  },
  { timestamps: true }
);

export default mongoose.model("Hotel", hotelSchema);
